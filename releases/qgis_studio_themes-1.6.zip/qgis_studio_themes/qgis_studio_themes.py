"""QGIS Studio Themes plugin.

Each theme is built from shared sources (themes/style.qss, themes/base.qss,
widget glyph templates in themes/icons/ and the modern QGIS icon set in
studio_icons.py) plus the theme's own themes/<folder>/variables.qss.
Built themes live in the profile's themes folder, which QGIS also searches
for theme icons, so dialogs opened later pick up the modern icons natively.
"""
import concurrent.futures
import ctypes
import functools
import hashlib
import json
import os
import re
import shutil
import queue
import sys
import threading
import time
from pathlib import Path

from qgis.core import Qgis, QgsApplication, QgsMessageLog, QgsProject, QgsSettings
from qgis.gui import QgsCollapsibleGroupBoxBasic, QgsFilterLineEdit
from qgis.PyQt import sip
from qgis.PyQt.QtCore import (
    QAbstractProxyModel, QBuffer, QByteArray, QDataStream, QEvent, QFile, QIODevice, QModelIndex, QObject,
    QPersistentModelIndex, QPointF, QRect, QRectF, QSize, Qt, QTimer, pyqtSignal, qVersion,
)
from qgis.PyQt.QtGui import (
    QAction, QBrush, QColor, QFont, QFontDatabase, QGuiApplication, QIcon, QIconEngine, QImage, QPainter,
    QPalette, QPixmap, QPixmapCache, QRegion, QStandardItemModel,
)
from qgis.PyQt.QtSvg import QSvgRenderer
from qgis.PyQt.QtWidgets import (
    QAbstractButton, QAbstractItemView, QAbstractSpinBox, QApplication, QComboBox, QDialog,
    QDialogButtonBox, QDockWidget, QFormLayout, QLabel, QListWidget, QMenu, QMenuBar, QStackedWidget,
    QStyle, QStyledItemDelegate, QVBoxLayout,
    QLineEdit, QProgressBar, QSizePolicy, QStyleOptionViewItem, QTabBar, QToolBar, QToolButton, QTreeView,
    QTreeWidget,
    QWidget,
)

from . import studio_icons, studio_toolbars
from .studio_events import EventHub, menu_of
from .studio_layers import LayersPanel
from .studio_ribbon import CAPTION_NAMES, CAPTION_POSITION, DEFAULT_DENSITY, DENSITIES, RIBBON_SIZES, StudioRibbon
from .studio_toolbars import NAME_STYLES, POSITIONS, TITLE_SIZE, TITLE_SIZES, WEIGHTS, ToolbarLabels, name_rules
from .studio_tokens import code_editor_ini, is_dark, parse_color, parse_tokens, render, resolve_tokens

PLUGIN_DIR = Path(__file__).parent
THEMES_DIR = PLUGIN_DIR / "themes"
SHARED_STYLE = THEMES_DIR / "style.qss"
SHARED_TOKENS = THEMES_DIR / "base.qss"
WIDGET_GLYPHS = THEMES_DIR / "icons"
FONTS_DIR = PLUGIN_DIR / "fonts"
METADATA = PLUGIN_DIR / "metadata.txt"
STAMP = ".studio-build"
# Bump when the layout of a built theme changes, so old builds are redone.
BUILD_FORMAT = "33"
FULL_STYLE = "style.full.qss"
# What QGIS loads for every Studio theme except the configured one (see
# QgisStudioThemesPlugin._select_style): a runtime switch then costs QGIS
# a near-empty pass, and the plugin applies the real stylesheet once,
# after installing the palette.
STUB_STYLE = b"/* Studio theme: the plugin applies the stylesheet. */\n"
LOG_TAG = "Studio Themes"
# The palette and font QGIS had before any Studio theme, kept on the
# application object so a reloaded or upgraded plugin (a new module and
# plugin object) still restores them, not the theme's.
ORIGINAL_PALETTE = "_studioOriginalPalette"
ORIGINAL_FONT = "_studioOriginalFont"
# Toolbar names: where they go, which name shows and its size and weight
# (studio_toolbars POSITIONS, NAME_STYLES, TITLE_SIZES, WEIGHTS), set in
# Plugins > QGIS Studio Themes > Settings.
# LABELS_SETTING, the on/off switch before 1.2, still turns them off when
# no position was chosen yet.
LABELS_SETTING = "studio_themes/toolbarLabels"
POSITION_SETTING = "studio_themes/toolbarNamePosition"
NAMES_SETTING = "studio_themes/toolbarNameText"
SIZE_SETTING = "studio_themes/toolbarNameSize"
# The interface: QGIS's toolbars ("toolbars") or the ribbon ("ribbon",
# studio_ribbon), set in the settings dialog.
INTERFACE_SETTING = "studio_themes/interface"
INTERFACES = ("toolbars", "ribbon")
WEIGHT_SETTING = "studio_themes/toolbarNameWeight"
# The ribbon's group names: where they go and which name shows, set apart
# from the toolbar names' (the font is shared), and the ribbon's size and
# density (studio_ribbon RIBBON_SIZES, DENSITIES).
RIBBON_POSITION_SETTING = "studio_themes/ribbonNamePosition"
RIBBON_NAMES_SETTING = "studio_themes/ribbonNameText"
RIBBON_SIZE_SETTING = "studio_themes/ribbonSize"
RIBBON_DENSITY_SETTING = "studio_themes/ribbonDensity"
MENU_NAME = "QGIS Studio Themes"
# Compact sizes: "auto" (by the screen's pixel density), "on" or "off".
COMPACT_SETTING = "studio_themes/compactSizes"
# Below this many (logical) pixels per inch every pixel is physically large,
# e.g. a 1920x1200 desktop monitor (~95 PPI) against a 14" laptop (~160).
COMPACT_MAX_PPI = 120
MENU_BAR_EXTRA_PT = 1
COMPACT_MENU_BAR_EXTRA_PT = 0.5
# Icon size of toolbars inside panels (QGIS uses 16 px there), on every
# screen, a step larger per larger icon size setting (set in code, see
# IconSwapper._panel_toolbar: a stylesheet size would undo the steps
# whenever Qt polishes a panel again).
DOCK_ICON_SIZE = 20
PANEL_ICON_RULES = (
    "QgsBrowserTreeView, QgsLayerTreeView, QgsProcessingToolboxTreeView"
    " { qproperty-iconSize: 20px 20px; }"
)

# QGIS adds these rules to the main window's own stylesheet when it starts
# with a theme that is not registered yet (ours register a moment later).
# They paint the default theme's dark options sidebar and blue table
# selection, and as a widget stylesheet they beat the application one.
DEFAULT_THEME_RULES = re.compile(
    r"[^{}]*(?:mOptionsListWidget|mOptionsListFrame|mOptionsTreeView)[^{}]*\{[^{}]*\}"
    r"|\s*QTableView\s*\{[^{}]*\}"
)
# The text colour QGIS writes into the status bar message's own stylesheet
# (not the background-color before it).
# Win32 window class style (set_popup_shadows).
GCL_STYLE = -26
CS_DROPSHADOW = 0x00020000
STATUS_TEXT_COLOR = re.compile(r"(?<![-\w])color:\s*[^;}]+")


def shared_sources():
    """Files every built theme depends on. An installed release changes
    them only together with metadata.txt, so that one stat() is enough; a
    git checkout (development) tracks every source file."""
    if not (PLUGIN_DIR / ".git").exists():
        return [METADATA]
    # studio_toolbars gives the toolbar name rules and sizes (tokens).
    sources = [
        METADATA, SHARED_STYLE, SHARED_TOKENS, Path(studio_icons.__file__), Path(studio_toolbars.__file__),
        Path(__file__),
    ]
    sources += sorted(WIDGET_GLYPHS.glob("*.svg"))
    sources += sorted(studio_icons.GLYPHS_DIR.glob("*.svg"))
    return sources


def icon_file(name):
    """Override file for a QGIS icon name. Always SVG: QGIS's few .png icons
    are only replaced through IconSwapper (QGIS's own lookup keeps
    resolving those to its built-in PNGs)."""
    return Path(name).with_suffix(".svg")


# Icon sizes (logical px) that get pixel-snapped PNGs: menus and trees (16),
# panel toolbars and the ribbon's small buttons (20), toolbars and dialog
# page lists (24), QGIS's own dialog page list size (28) and the ribbon's
# large buttons (32). QGIS's configured toolbar size and the lists' and
# trees' sizes for it are added at runtime (see IconSwapper._extra_sizes),
# so the larger sizes are only rendered when chosen; any other size is drawn
# on demand (SharpIconEngine).
PNG_SIZES = (16, 20, 24, 28, 32)
# On scaled screens every PNG is loaded up front (see IconSwapper._icon).
SCALED_PNG_SIZES = PNG_SIZES


def screen_ratios():
    """The device pixel ratios of all screens (1.0, 1.25, 1.5...)."""
    return frozenset(round(screen.devicePixelRatio(), 2) for screen in QGuiApplication.screens()) or {1.0}


def logical_sizes(ratios, extra_sizes):
    """The logical icon sizes to provide PNGs for on these screens, with
    `extra_sizes` (QGIS's toolbar and dialog page list sizes)."""
    sizes = set(PNG_SIZES if ratios == {1.0} else SCALED_PNG_SIZES)
    sizes.update(size for size in extra_sizes if 8 <= size <= 96)
    return tuple(sorted(sizes))


def device_sizes(ratios, sizes):
    """The PNGs needed for `sizes` on screens at `ratios`: (pixel size,
    line width) pairs, the width being the screen's (see
    studio_icons.screen_stroke_px)."""
    return frozenset(
        (round(size * ratio), studio_icons.screen_stroke_px(ratio)) for size in sizes for ratio in ratios
    )


def icon_colors(tokens):
    """Colours of a theme's icons in each state of ICON_STATES: normal,
    disabled and selected."""
    colors = {
        "icon": tokens["@icon"],
        "accent": tokens["@icon_accent"],
        "danger": tokens["@danger"],
        # The window colour, for Colourful icons' light or dark hues.
        "window": tokens["@bg_window"],
    }
    # Disabled state: glyph and badge both in the theme's disabled icon
    # colour (dimmer than disabled text: clearly unavailable).
    disabled = dict(dict.fromkeys(colors, tokens["@icon_disabled"]), window=colors["window"])
    # Selected rows (dialog page lists, Browser, Processing Toolbox): the
    # glyph in the accent, a shade towards the text so it keeps its
    # contrast on the accent-tinted selection.
    selected = dict(colors, icon=tokens["@icon_selected"])
    return colors, disabled, selected


# Icon states drawn by the theme, with the QIcon mode each one serves.
ICON_STATES = (
    ("normal", QIcon.Mode.Normal),
    ("disabled", QIcon.Mode.Disabled),
    ("selected", QIcon.Mode.Selected),
)
# Pre-rendered icons live in atlases: every distinct drawing in a cell of a
# grid this many cells wide, in atlas_specs() order. One file per atlas
# instead of one per icon: Qt reads a few images instead of thousands, and
# on Windows every small file opened also costs a virus scan.
ATLAS_COLUMNS = 32
# The atlases are drawn once as colourless masks per (pixel size, line
# width, glyph scale), shared by every theme and state, and coloured when
# loaded (see compose_atlas): a glyph layer (everything in the icon colour)
# and the two coloured badge layers. Badges never touch the glyph (it is
# cut away around them), so tinting each layer is exact. Masks are drawn
# once per profile in the background (a fraction of a second per size).
# The Colourful style adds a colour layer per kind of theme, light and
# dark ("color-light", "color-dark": every coloured part in its own colour,
# stored in colour), and "ink", the parts drawn in the theme's icon colour
# (a mask, tinted when loaded).
MASK_FORMAT = 19
MASK_LAYERS = {
    "glyph": {"icon": "#000000", "accent": "none", "danger": "none"},
    "accent": {"icon": "none", "accent": "#000000", "danger": "none"},
    "danger": {"icon": "none", "accent": "none", "danger": "#000000"},
    "color-light": None,
    "color-dark": None,
    "ink": None,
}
# Icon styles (Settings > Icons): the theme's single-colour icons, the same
# icons in their objects' colours (studio_icons.COLOR_RECIPES), or QGIS's
# own icons.
ICON_STYLES = ("mono", "color", "classic")
ICON_STYLE_SETTING = "studio_themes/iconStyle"
# A disabled Colourful icon: its colours faded, its ink in the theme's
# disabled icon colour.
DISABLED_COLOR_OPACITY = 0.5


def atlas_specs():
    """The distinct drawings, in atlas order."""
    return sorted(set(studio_icons.ICON_MAP.values()))


def atlas_index():
    """Atlas cell of each drawing (spec)."""
    return {spec: index for index, spec in enumerate(atlas_specs())}


def atlas_cell(index, size):
    return QRect((index % ATLAS_COLUMNS) * size, (index // ATLAS_COLUMNS) * size, size, size)


@functools.lru_cache(maxsize=1)
def masks_key():
    """Names the masks of these drawings, as studio_icons draws them: masks
    of another plugin version are never used."""
    digest = hashlib.sha1(f"{MASK_FORMAT}|{ATLAS_COLUMNS}|{'|'.join(atlas_specs())}".encode())
    digest.update(Path(studio_icons.__file__).read_bytes().replace(b"\r\n", b"\n"))
    return digest.hexdigest()[:16]


def mask_folders(profile_masks):
    """Where masks are looked up (and drawn): the folder of this version's
    drawings in the profile's mask folder `profile_masks`."""
    return (profile_masks / masks_key(),)


def mask_path(folder, size, width, scale, layer):
    return folder / f"{size}w{width}s{scale:g}-{layer}.png"


def find_masks(folders, size, width, scale):
    """The folder holding the complete masks of one size, or None. The
    glyph layer is written last, so it marks a complete set."""
    for folder in folders:
        if mask_path(folder, size, width, scale, "glyph").exists():
            return folder
    return None


def missing_masks(folders, sizes, scale):
    """The (pixel size, line width) pairs of `sizes` without masks."""
    return frozenset(pair for pair in sizes if find_masks(folders, *pair, scale) is None)


def badge_layer(spec):
    """The mask layer of a drawing's coloured badge (None if it has none:
    +, - and check marks are drawn in the icon colour)."""
    badge = spec.partition("+")[2]
    if not badge or badge in studio_icons.BADGE_MARKS:
        return None
    return "danger" if badge == "x" else "accent"


def tinted(mask, color):
    """A mask (Alpha8) in one colour."""
    image = mask.convertToFormat(QImage.Format.Format_ARGB32_Premultiplied)
    painter = QPainter(image)
    painter.setCompositionMode(QPainter.CompositionMode.CompositionMode_SourceIn)
    painter.fillRect(image.rect(), color)
    painter.end()
    return image


def compose_atlas(masks, colors, color=False, faded=False):
    """One state's atlas from the masks of a size: the glyph layer in the
    icon colour, the badge layers in theirs (QColor values in `colors`).
    With `color` (the Colourful style), the colour layer of the theme's kind
    (light or dark, by its window colour) as drawn, `faded` for the
    disabled state, under the ink layer in the icon colour. A few
    image operations in Qt, instead of drawing every icon again."""
    if color:
        layer = masks["color-dark" if colors["window"].lightness() < 128 else "color-light"]
        atlas = QImage(layer.size(), QImage.Format.Format_ARGB32_Premultiplied)
        atlas.fill(Qt.GlobalColor.transparent)
        painter = QPainter(atlas)
        painter.setOpacity(DISABLED_COLOR_OPACITY if faded else 1.0)
        painter.drawImage(0, 0, layer)
        painter.setOpacity(1.0)
        painter.drawImage(0, 0, tinted(masks["ink"], colors["icon"]))
    else:
        atlas = tinted(masks["glyph"], colors["icon"])
        painter = QPainter(atlas)
    # Colourful icons draw delete's red cross in their colour layer
    # (studio_icons.COLOR_BADGE_MARKS): the danger layer's red dot is only
    # for single-colour icons.
    for layer in ("accent",) if color else ("accent", "danger"):
        painter.drawImage(0, 0, tinted(masks[layer], colors[layer]))
    painter.end()
    return QPixmap.fromImage(atlas)


def write_atomic(path, data):
    """Write `data` (bytes) so that `path` is never left half written: a
    file cut short by a crash would otherwise be trusted forever."""
    temporary = path.with_name(path.name + ".tmp")
    temporary.write_bytes(data)
    os.replace(temporary, path)


def state_path(icons_dir, name, state):
    """Disabled or selected drawing of an icon, shared by every name with
    the same spec. Qt's own disabled rendering fades icons almost into the
    background; these use the theme's @icon_disabled instead."""
    return icons_dir / state / f"{studio_icons.ICON_MAP[name]}.svg"


def render_masks(folder, size, width, scale, stop):
    """Draw the masks of every distinct icon at one (pixel size, line
    width, glyph scale), each drawn for that exact size with its lines on
    the pixel grid (studio_icons.render_icon_px), so it is shown 1:1,
    never resampled. Safe in a worker thread (QImage painting needs no GUI
    thread). False if stopped."""
    specs = atlas_specs()
    rows = -(-len(specs) // ATLAS_COLUMNS)
    images = {}
    painters = {}
    for layer in MASK_LAYERS:
        image = QImage(ATLAS_COLUMNS * size, rows * size, QImage.Format.Format_ARGB32_Premultiplied)
        image.fill(Qt.GlobalColor.transparent)
        images[layer] = image
        painters[layer] = QPainter(image)
    try:
        for index, spec in enumerate(specs):
            if stop.is_set():
                return False
            cell = QRectF(atlas_cell(index, size))
            for layer in ("glyph", badge_layer(spec)):
                if layer is not None:
                    svg = studio_icons.render_icon_px(spec, MASK_LAYERS[layer], size, scale, width)
                    QSvgRenderer(QByteArray(svg.encode("utf-8"))).render(painters[layer], cell)
            for mode in studio_icons.COLOR_MODES:
                svg = studio_icons.render_icon_color_px(spec, size, scale, width, "color", mode=mode)
                QSvgRenderer(QByteArray(svg.encode("utf-8"))).render(painters[f"color-{mode}"], cell)
            svg = studio_icons.render_icon_color_px(spec, size, scale, width, "ink")
            QSvgRenderer(QByteArray(svg.encode("utf-8"))).render(painters["ink"], cell)
            time.sleep(0)  # let the GUI thread take Python's lock if it waits
    finally:
        for painter in painters.values():
            painter.end()
    folder.mkdir(parents=True, exist_ok=True)
    # The glyph layer last: it marks the set complete (see find_masks).
    for layer in ("accent", "danger", "color-light", "color-dark", "ink", "glyph"):
        data = QByteArray()
        buffer = QBuffer(data)
        buffer.open(QIODevice.OpenModeFlag.WriteOnly)
        # The colour layer keeps its colours; the others are masks.
        image = images[layer] if layer.startswith("color") else images[layer].convertToFormat(QImage.Format.Format_Alpha8)
        if not image.save(buffer, "PNG"):
            raise OSError(f"could not encode the {layer} masks")
        buffer.close()
        write_atomic(mask_path(folder, size, width, scale, layer), bytes(data))
    return True


def render_one(spec, size, width, scale):
    """The mask layers of one drawing at one exact pixel size, drawn as
    render_masks draws an atlas cell (same layers and formats as
    load_masks): for sizes no atlas covers, so they are never resampled."""
    cell = QRectF(0, 0, size, size)
    images = {}
    for layer in MASK_LAYERS:
        image = QImage(size, size, QImage.Format.Format_ARGB32_Premultiplied)
        image.fill(Qt.GlobalColor.transparent)
        images[layer] = image

    def draw(layer, svg):
        painter = QPainter(images[layer])
        QSvgRenderer(QByteArray(svg.encode("utf-8"))).render(painter, cell)
        painter.end()

    for layer in ("glyph", badge_layer(spec)):
        if layer is not None:
            draw(layer, studio_icons.render_icon_px(spec, MASK_LAYERS[layer], size, scale, width))
    for mode in studio_icons.COLOR_MODES:
        draw(f"color-{mode}", studio_icons.render_icon_color_px(spec, size, scale, width, "color", mode=mode))
    draw("ink", studio_icons.render_icon_color_px(spec, size, scale, width, "ink"))
    return {
        layer: image if layer.startswith("color") else image.convertToFormat(QImage.Format.Format_Alpha8)
        for layer, image in images.items()
    }


@functools.lru_cache(maxsize=1)
def scaled_size_is_logical():
    """Whether this Qt hands QIconEngine.scaledPixmap the logical size
    (Qt 6.8 and later) or the size already multiplied by the scale."""
    seen = []

    class Probe(QIconEngine):
        def scaledPixmap(self, size, mode, state, scale):  # pylint: disable=invalid-name,unused-argument
            seen.append(size.width())
            return QPixmap()

        def pixmap(self, size, mode, state):  # pylint: disable=unused-argument
            seen.append(size.width())
            return QPixmap()

        def clone(self):
            return Probe()

    QIcon(Probe()).pixmap(QSize(10, 10), 2.0)
    return not seen or seen[0] == 10


class SharpIconEngine(QIconEngine):
    """One of our icons, always shown 1:1 in device pixels: the
    pre-rendered pixmap when one exists for the exact size asked for, else
    that size drawn once on the pixel grid (render_one) and kept. A plain
    pixmap icon holds only the pre-rendered sizes and has Qt resample the
    nearest for any other (QGIS's font-scaled icon sizes, large toolbar
    settings, dialog icons, other screens), which blurs it."""

    STATES = {
        QIcon.Mode.Normal: "normal", QIcon.Mode.Active: "normal",
        QIcon.Mode.Disabled: "disabled", QIcon.Mode.Selected: "selected",
    }

    def __init__(self, swapper, name):
        super().__init__()
        self._swapper = swapper
        self._name = name

    def _get(self, size, mode, scale):
        side = min(size.width(), size.height())
        if side <= 0:
            return QPixmap()
        ratio = round(scale, 2) if scale and scale > 0 else 1.0
        pixmap = self._swapper.exact_pixmap(self._name, max(1, round(side * ratio)), self.STATES.get(mode, "normal"),
                                            ratio)
        return QPixmap() if pixmap is None else pixmap

    def pixmap(self, size, mode, state):  # pylint: disable=unused-argument
        return self._get(size, mode, 1.0)

    def scaledPixmap(self, size, mode, state, scale):  # pylint: disable=invalid-name,unused-argument
        if not scaled_size_is_logical() and scale > 0:
            size = QSize(round(size.width() / scale), round(size.height() / scale))
        return self._get(size, mode, scale)

    def paint(self, painter, rect, mode, state):  # pylint: disable=unused-argument
        device = painter.device()
        pixmap = self._get(rect.size(), mode, device.devicePixelRatioF() if device is not None else 1.0)
        if pixmap.isNull():
            return
        side = pixmap.width() / pixmap.devicePixelRatio()
        # Centred on whole device pixels, so it is drawn 1:1.
        x = rect.x() + (rect.width() - side) / 2
        y = rect.y() + (rect.height() - side) / 2
        painter.drawPixmap(QPointF(round(x), round(y)), pixmap)

    def actualSize(self, size, mode, state):  # pylint: disable=invalid-name,unused-argument
        side = min(size.width(), size.height())
        return QSize(side, side)

    def availableSizes(self, mode=QIcon.Mode.Normal, state=QIcon.State.Off):  # pylint: disable=invalid-name,unused-argument
        return [QSize(size, size) for size in self._swapper.png_sizes()]

    def clone(self):
        return SharpIconEngine(self._swapper, self._name)

    def key(self):
        return "studio-sharp"


def load_masks(folder, size, width, scale):
    """The mask layers of one size (Alpha8; the colour layer in colour),
    None if unreadable."""
    masks = {}
    for layer in MASK_LAYERS:
        image = QImage(str(mask_path(folder, size, width, scale, layer)))
        if image.isNull():
            return None
        masks[layer] = image.convertToFormat(
            QImage.Format.Format_ARGB32_Premultiplied if layer.startswith("color") else QImage.Format.Format_Alpha8)
    return masks


# Threads writing a theme's icon files (see build_theme).
WRITE_THREADS = 8


def write_if_changed(path, text, written):
    """Write a build file unless it already holds `text`: an upgrade then
    rewrites only what changed (reading is much cheaper than writing), and
    a file cut short by a crash is repaired. Adds `path` to `written`.
    `text` may also be bytes."""
    data = text if isinstance(text, bytes) else text.encode("utf-8")
    written.add(path)
    try:
        if path.read_bytes() == data:
            return
    except OSError:
        pass
    path.write_bytes(data)


def classic_icon(name):
    """QGIS's own drawing of an icon of its default theme (bytes), None if
    it has none. Reading Qt resources is safe in any thread."""
    resource = QFile(f":/images/themes/default/{name}")
    if not resource.open(QIODevice.OpenModeFlag.ReadOnly):
        return None
    try:
        return bytes(resource.readAll())
    finally:
        resource.close()


def build_stamp(sources):
    digest = hashlib.sha1()
    for source in sources:
        stat = source.stat()
        digest.update(f"{source.name}:{stat.st_size}:{stat.st_mtime_ns};".encode())
    return digest.hexdigest()


def load_tokens(folder):
    return resolve_tokens(parse_tokens(
        SHARED_TOKENS.read_text(encoding="utf-8"),
        (THEMES_DIR / folder / "variables.qss").read_text(encoding="utf-8"),
    ))


def prerender_masks(folders, sizes, scale, stop):
    """Draw the masks of the (pixel size, line width) pairs `sizes` that
    are not there yet into the profile's mask folder (worker thread), one
    size at a time, so an interrupted run keeps what it finished. Returns
    True once all are written, False if stopped or failed."""
    try:
        for size, width in sorted(missing_masks(folders, sizes, scale)):
            if not render_masks(folders[-1], size, width, scale, stop):
                return False
    except OSError:
        return False
    prune_masks(folders[-1])
    return True


def prune_masks(folder):
    """Delete the masks of other plugin versions next to `folder`: each
    version draws its own set, and nothing else ever removes them."""
    for other in folder.parent.iterdir():
        if other.is_dir() and other != folder:
            shutil.rmtree(other, ignore_errors=True)


def build_theme(folder, target, shared_stamp, active, extra_tokens=None,
                icon_scale=studio_icons.SCALE, icon_style="mono"):
    """Write the resolved stylesheet and all icons for one theme into
    `target`, in `icon_style` (ICON_STYLES; "classic" writes QGIS's own);
    style.qss gets the real stylesheet only when `active` (see
    STUB_STYLE). Skipped when nothing changed since the last build, so
    startup costs only a few stat() calls; a rebuild rewrites only the
    files whose content changed. Thread-safe (no GUI calls). Returns True
    when it (re)built the theme. `shared_stamp` must name the icon style."""
    stamp = build_stamp([THEMES_DIR / folder / "variables.qss"]) + shared_stamp
    stamp_file = target / STAMP
    if stamp_file.exists() and stamp_file.read_text(encoding="utf-8") == stamp:
        return False
    tokens = load_tokens(folder)
    # Forward slashes: Windows backslashes would break url() parsing.
    tokens["@theme_path"] = target.as_posix()
    # Values that depend on the user's QGIS settings (part of shared_stamp).
    tokens.update(extra_tokens or {})
    icons = target / "icons"
    # Per-theme atlases of earlier versions (now composed from the shared
    # masks when loaded).
    if (icons / "png").exists():
        shutil.rmtree(icons / "png")
    (icons / "studio").mkdir(parents=True, exist_ok=True)
    written = set()

    style, unknown = render(SHARED_STYLE.read_text(encoding="utf-8"), tokens)
    for template in WIDGET_GLYPHS.glob("*.svg"):
        svg, missing = render(template.read_text(encoding="utf-8"), tokens)
        unknown |= missing
        write_if_changed(icons / "studio" / template.name, svg, written)
    if unknown:
        QgsMessageLog.logMessage(
            f"{folder}: unresolved tokens {sorted(unknown)}", LOG_TAG, Qgis.MessageLevel.Warning
        )
    colors = dict(zip((state for state, _mode in ICON_STATES), icon_colors(tokens)))
    folders = set()
    svgs = {}
    color = icon_style == "color"
    mode = "dark" if is_dark(tokens["@bg_window"]) else "light"

    def drawing(spec, state):
        # Disabled Colourful icons are the theme's disabled single-colour
        # ones here (only shown until the pre-rendered PNGs are ready).
        if color and state != "disabled":
            return studio_icons.render_icon_color(spec, colors[state], icon_scale, mode)
        return studio_icons.render_icon(spec, colors[state], icon_scale)

    pending = []
    for name, spec in studio_icons.ICON_MAP.items() if icon_style != "classic" else ():
        path = icons / icon_file(name)
        if path.parent not in folders:
            path.parent.mkdir(parents=True, exist_ok=True)
            folders.add(path.parent)
        if spec not in svgs:
            svgs[spec] = drawing(spec, "normal")
            for state in ("disabled", "selected"):
                state_file = icons / state / f"{spec}.svg"
                if state_file.parent not in folders:
                    state_file.parent.mkdir(parents=True, exist_ok=True)
                    folders.add(state_file.parent)
                pending.append((state_file, drawing(spec, state)))
        pending.append((path, svgs[spec]))
    if icon_style == "classic":
        # QGIS's own icons, as files: QGIS keeps every icon it loaded from
        # this folder by its path until it restarts, and would show those
        # blank once the files were gone (after a switch from another style).
        for name in studio_icons.ICON_MAP:
            data = classic_icon(name) if name.endswith(".svg") else None
            if data is not None:
                path = icons / name
                if path.parent not in folders:
                    path.parent.mkdir(parents=True, exist_ok=True)
                    folders.add(path.parent)
                pending.append((path, data))
    # About 2,000 small files, each costing mostly the wait for the file
    # system (and a virus scanner), not Python: written side by side.
    with concurrent.futures.ThreadPoolExecutor(WRITE_THREADS) as pool:
        for _ in pool.map(lambda job: write_if_changed(*job, written), pending):
            pass
    # Icons of names no longer mapped (or of another style) would still be
    # found by QGIS.
    for root, dirs, files in os.walk(icons):
        if Path(root) == icons:
            dirs[:] = [d for d in dirs if d != "png"]
        for file_name in files:
            if Path(root, file_name) not in written:
                Path(root, file_name).unlink(missing_ok=True)
    # Code editor colours (QGIS reads them from the theme folder).
    write_if_changed(target / "qscintilla.ini", code_editor_ini(tokens), set())
    (target / FULL_STYLE).write_text(style, encoding="utf-8")
    if active:
        shutil.copyfile(target / FULL_STYLE, target / "style.qss")
    else:
        (target / "style.qss").write_bytes(STUB_STYLE)
    stamp_file.write_text(stamp, encoding="utf-8")
    return True


def set_tabular_digits(font):
    """Inter's tabular (equal width) digits: numbers that change in place
    (coordinates and scale in the status bar, spin boxes, shortcuts in
    menus) keep their width instead of jittering. Needs Qt 6.7."""
    if not hasattr(font, "setFeature"):
        return
    try:
        tag = QFont.Tag.fromString("tnum")
        if tag is not None:
            font.setFeature(tag, 1)
    except (AttributeError, TypeError, ValueError):
        pass


def set_popup_shadows(enabled):
    """Windows draws a soft shadow along the right and bottom edge of
    menus, drop-down lists and tooltips (CS_DROPSHADOW on the window
    classes Qt registers for them), which reads as dated next to the flat
    theme. The flag belongs to the window class, which every popup (or
    tooltip) of the process shares, so it is cleared once, on a throwaway
    window of each kind, and set again when leaving the Studio themes."""
    if sys.platform != "win32":
        return
    user32 = ctypes.windll.user32
    user32.GetClassLongPtrW.restype = ctypes.c_size_t
    user32.GetClassLongPtrW.argtypes = (ctypes.c_void_p, ctypes.c_int)
    user32.SetClassLongPtrW.restype = ctypes.c_size_t
    user32.SetClassLongPtrW.argtypes = (ctypes.c_void_p, ctypes.c_int, ctypes.c_size_t)
    for kind in (Qt.WindowType.Popup, Qt.WindowType.ToolTip):
        probe = QWidget(None, kind)
        # Qt gives tooltips their shadow class through this property.
        probe.setProperty("_q_windowsDropShadow", True)
        hwnd = int(probe.winId())
        style = user32.GetClassLongPtrW(hwnd, GCL_STYLE)
        wanted = style | CS_DROPSHADOW if enabled else style & ~CS_DROPSHADOW
        if wanted != style:
            user32.SetClassLongPtrW(hwnd, GCL_STYLE, wanted)
        probe.deleteLater()


def qcolor(value):
    """A resolved token colour as a QColor."""
    r, g, b, a = parse_color(value)
    return QColor(round(r), round(g), round(b), round(a * 255))


def make_palette(tokens):
    """Qt palette for the theme: plain widgets get their colours from here
    instead of from broad stylesheet rules."""
    def color(token):
        return qcolor(tokens[token])

    role = QPalette.ColorRole
    group = QPalette.ColorGroup
    palette = QPalette()
    for target_role, token in (
        (role.Window, "@bg_window"), (role.WindowText, "@text"),
        (role.Base, "@bg_base"), (role.AlternateBase, "@header_bg"),
        (role.Text, "@text"), (role.Button, "@control_bg"),
        (role.ButtonText, "@text"), (role.BrightText, "@text_bright"),
        # Lists, trees and tables draw selection natively from these.
        (role.Highlight, "@row_selected"), (role.HighlightedText, "@text_bright"),
        (role.ToolTipBase, "@bg_menu"), (role.ToolTipText, "@text"),
        (role.PlaceholderText, "@text_placeholder"), (role.Link, "@accent"),
        (role.LinkVisited, "@accent_pressed"), (role.Light, "@divider_strong"),
        (role.Midlight, "@divider"), (role.Mid, "@divider_strong"),
        (role.Dark, "@field_border"), (role.Shadow, "@border_darker"),
    ):
        palette.setColor(group.All, target_role, color(token))
    for target_role in (role.WindowText, role.Text, role.ButtonText):
        palette.setColor(group.Disabled, target_role, color("@text_disabled"))
    palette.setColor(group.Disabled, role.Base, color("@bg_window"))
    palette.setColor(group.Disabled, role.Button, color("@control_pressed"))
    palette.setColor(group.Inactive, role.Highlight, color("@row_selected_inactive"))
    palette.setColor(group.Inactive, role.HighlightedText, color("@text"))
    return palette


class _IconDelegate(QStyledItemDelegate):
    """Draws a view's rows with the theme's icons, for views whose model
    cannot be edited: the Processing Toolbox, whose icons come from QGIS's
    icon cache (filled before the Studio themes were registered) or from
    the Processing plugin's own image files, and the Browser, whose rows
    would otherwise show the theme's SVGs (not pixel-snapped, so heavier
    than the toolbar icons on screens at 100 percent), and the Processing
    and query History dialogs, whose entries show the algorithm's icon.

    With `soften`, a fixed background colour QGIS gives a cell (the Fields
    page paints every provider field a translucent yellow, olive on a dark
    theme) is blended into the view's base colour: the rows it marks stay
    told apart, in the theme's palette."""

    SOFTEN = 0.05

    def __init__(self, swapper, parent, by_row=True, folders=True, soften=False):
        super().__init__(parent)
        self._swapper = swapper
        self._by_row = by_row
        # Rows with children are groups (Processing Toolbox), not History
        # entries, whose children are their details.
        self._folders = folders
        self._soften = soften

    def initStyleOption(self, option, index):  # pylint: disable=invalid-name
        super().initStyleOption(option, index)
        if self._soften:
            # Painted softened in paint(), under the row.
            option.backgroundBrush = QBrush()
        if option.icon.isNull():
            return
        if self._by_row:
            # Keyed by the row (tool and its group), not by the icon object:
            # Processing plugin tools create a new QIcon on every paint.
            parent = index.parent()
            row = (index.data(), parent.data(), parent.parent().data())
            group = self._folders and index.model().hasChildren(index)
            icon = self._swapper.row_icon(row, option.icon, group)
        else:
            # Keyed by the icon: a Browser row changes its icon (folder
            # open or closed, loading).
            icon = self._swapper.keyed_icon(option.icon)
        if icon is not None:
            option.icon = icon


    def paint(self, painter, option, index):
        if self._soften:
            brush = index.data(Qt.ItemDataRole.BackgroundRole)
            if isinstance(brush, (QBrush, QColor)):
                tint = brush.color() if isinstance(brush, QBrush) else brush
                base = option.palette.color(QPalette.ColorRole.Base)
                # A translucent colour (QGIS's yellow) counts for what it
                # covers, at most SOFTEN.
                t = min(self.SOFTEN, tint.alphaF() * 0.35)
                painter.fillRect(option.rect, QColor(
                    round(base.red() * (1 - t) + tint.red() * t),
                    round(base.green() * (1 - t) + tint.green() * t),
                    round(base.blue() * (1 - t) + tint.blue() * t),
                ))
        super().paint(painter, option, index)


class _LayerTreeDelegate(QStyledItemDelegate):
    """Draws the Layers panel's rows with the theme's icons. Its own
    delegate (QgsLayerTreeViewItemDelegate, not available to Python) draws
    the layer indicators and handles their clicks and tooltips, so it still
    draws every row; only the icon square is drawn again, here, with our
    icon (same background and state, so the two parts match)."""

    def __init__(self, swapper, parent, original):
        super().__init__(parent)
        self._swapper = swapper
        self._original = original

    def paint(self, painter, option, index):
        # Most rows show a symbol or legend pixmap, not one of our icons:
        # those are handed straight to the original delegate.
        icon = index.data(Qt.ItemDataRole.DecorationRole)
        icon = self._swapper.keyed_icon(icon) if isinstance(icon, QIcon) else None
        if icon is None:
            self._original.paint(painter, option, index)
            return
        opt = QStyleOptionViewItem(option)
        self.initStyleOption(opt, index)
        widget = opt.widget
        style = widget.style() if widget is not None else QApplication.style()
        square = style.subElementRect(QStyle.SubElement.SE_ItemViewItemDecoration, opt, widget)
        painter.save()
        painter.setClipRegion(QRegion(option.rect).subtracted(QRegion(square)), Qt.ClipOperation.IntersectClip)
        self._original.paint(painter, option, index)
        painter.restore()
        painter.save()
        painter.setClipRect(square, Qt.ClipOperation.IntersectClip)
        opt.icon = icon
        style.drawControl(QStyle.ControlElement.CE_ItemViewItem, opt, painter, widget)
        painter.restore()

    def sizeHint(self, option, index):  # pylint: disable=invalid-name
        return self._original.sizeHint(option, index)

    def helpEvent(self, event, view, option, index):  # pylint: disable=invalid-name
        # Indicator tooltips.
        return self._original.helpEvent(event, view, option, index)


class IconSwapper(QObject):
    """Replaces QGIS icons that QGIS created from its built-in set.

    Existing widgets are swapped once when the theme becomes active. New
    windows and pages are swapped when Qt polishes them, right before they
    are first shown, so they never appear with the old icons: dialogs are
    caught through the main window's ChildPolished events, pages that
    panels build later (Labels, renderer and symbol panels) through the
    ChildPolished events of the stacked widgets that host them. Each new
    window or page is scanned once, and only a handful of objects carry an
    event filter, so nothing runs per event across the application.
    Popups and windows without a parent are caught when they get focus.

    Icons are identified by QIcon.cacheKey() first: getThemeIcon() caches
    one QIcon per name and every widget shares that instance. Icons loaded
    straight from Qt Designer .ui files are separate instances; those are
    identified by their serialized SVG data, compared with the built-in
    icon. That reference table is cached on disk per QGIS build."""

    PROPERTY = "_studioIconsTheme"
    RESOURCES = ":/images/themes/default/"
    BATCH = 60
    # Bookkeeping is pruned of deleted objects once it doubles (see _compact).
    COMPACT_MIN = 500
    # The only widgets _visit acts on: a scan asks Qt for these in one call
    # instead of walking every widget of a window from Python.
    ICON_TYPES = (
        QAbstractButton, QToolBar, QMenuBar, QListWidget, QComboBox, QTabBar, QMenu, QStackedWidget,
        QAbstractItemView, QgsFilterLineEdit, QDockWidget,
    )
    # Item views on a QStandardItemModel (e.g. the Options page tree) are
    # swapped item by item; larger models hold data, not navigation icons.
    MODEL_LIMIT = 200
    # The built-in icon fingerprints are computed this long after the theme
    # is applied, WARM_BATCH icons per event-loop pass, so the first dialog
    # opened never pays for all of them at once.
    WARM_DELAY = 4000
    # Processing Toolbox: icons that say "QGIS tool" rather than what the
    # row is; on group rows they are replaced by a toolbox, as ArcGIS shows
    # its toolboxes (the tools in them keep their own icons).
    GENERIC_ICONS = frozenset({"providerQgis.svg", "processingAlgorithm.svg"})
    GROUP_ICON = "processingToolbox.svg"
    # Options > General > UI Theme: QGIS fills it in hash order.
    THEME_COMBO = "cmbUITheme"
    WARM_BATCH = 25
    _DECORATION = Qt.ItemDataRole.DecorationRole
    _UNKNOWN = object()
    _CHILD_POLISHED = QEvent.Type.ChildPolished
    _SHOW = QEvent.Type.Show
    _ACTION_ADDED = QEvent.Type.ActionAdded
    _PALETTE_CHANGE = QEvent.Type.PaletteChange

    def __init__(self, cache_file=None, profile_masks=None, hub=None):
        super().__init__()
        self._cache_file = cache_file
        # The event filter shared with the toolbar names (see studio_events).
        self._hub = hub if hub is not None else EventHub()
        # Where the icon masks are found (see mask_folders), the glyph scale
        # they are drawn at and the active theme's icon colours per state
        # (QColor values, see icon_colors).
        self._mask_folders = mask_folders(profile_masks) if profile_masks is not None else ()
        self._scale = studio_icons.SCALE
        self._colors = None
        # Low-density screens (the plugin's compact sizes), as last applied.
        self._compact_screens = False
        # The icon style (ICON_STYLES): "classic" swaps only icons QGIS
        # looked up by name, for its built-in ones (see _replacement), the
        # swapper still doing its other work (checkboxes, page lists).
        self._style = "mono"
        # QGIS's built-in icons by name, for the classic style.
        self._classics = {}
        self._swapped = []
        self._watched = {}
        self._models = {}
        self._filtered = []
        self._stacks = {}
        self._menus = {}
        # Widget classes _visit failed on (logged once each).
        self._failed_classes = set()
        self._docks = set()
        # The status bar's CRS button (see _hook_crs), once hooked.
        self._crs_button = None
        # Toolbars and menu bars watched for actions added later (a plugin
        # turned on, Processing re-enabled...).
        self._bars = set()
        self._delegates = {}
        # Collapsible group boxes whose collapse button is swapped again on
        # every open and close (see _hook_collapse).
        self._collapsibles = {}
        # Tool buttons swapped again on every click (see _hook_toggle).
        self._toggles = {}
        # Page lists with their own icon size (see _page_list), and feature
        # picker text fields (see _hook_picker).
        self._page_lists = {}
        self._pickers = {}
        # Main panel trees given the icon size setting's size (_panel_tree),
        # and panel toolbars given their larger icons (_panel_toolbar), with
        # their own: {id: (widget, QSize)}.
        self._trees = {}
        self._panel_bars = {}
        # Panel search fields given a magnifier (_panel_search): {id: (field,)}.
        self._searches = {}
        # Trees whose row-wide focus frame is turned off (see _row_focus),
        # and dialogs kept large enough for their contents, with QGIS's own
        # minimum size (see _hold_room).
        self._row_focus = {}
        self._rooms = {}
        # Option dialog pages whose width policy is relaxed (_relax_page).
        self._relaxed = {}
        # Icon names of rows drawn by delegated views, per row identity.
        self._view_names = {}
        # (screen ratios, logical sizes) while the pre-rendered icons are
        # used, else None (see _pngs_usable).
        self._png = None
        # Masks of single icons drawn for sizes no atlas covers, per (spec,
        # pixel size, line width, scale), shared by every theme (see
        # exact_pixmap).
        self._one_masks = {}
        # Icons cut from the atlases per (spec, pixel size, state, ratio),
        # shared by every icon name with the same drawing, the active
        # theme's atlases per (pixel size, line width, state) (None if
        # unreadable) and the masks they are composed from, kept across
        # theme switches, per (pixel size, line width, scale).
        self._pixmaps = {}
        self._atlases = {}
        self._atlas_index = {}
        self._masks = {}
        # QGIS's toolbar and dialog page list icon sizes, which get PNGs of
        # their own.
        self._extra_sizes = (24, self.PAGE_LIST_ICON)
        self._main_window = None
        self._scanned = []
        self._names = {}
        self._base_names = {}
        self._compact_at = self.COMPACT_MIN
        self._ours = {}
        self._reference_table = None
        # The disk cache is read once; a stale or missing one is recomputed.
        self._cache_checked = False
        # Built incrementally in idle time (see _warm_reference), started
        # early when a panel needs it (see _request_reference).
        self._reference_partial = None
        self._reference_queue = None
        self._warming = False
        # availableSizes() signatures of the built-in PNG icons: the only
        # pixmap-based icons worth fingerprinting (see _replacement).
        self._png_signatures = None
        # The same for just the built-in PNG icons, read on first need
        # while the full table is not ready (see _png_signature_set).
        self._quick_png_signatures = None
        # Icon names of icons drawn by the Browser and Layers delegates,
        # by cacheKey (bounded; pixmap icons are never remembered).
        self._key_names = {}
        # Icon names by icon slot (window class, parent and widget names,
        # slot; see _slot), for the icons only fingerprints can identify:
        # dialogs load new copies of their .ui icons on every open, which
        # are then recognised without fingerprinting them again. Kept in
        # the fingerprint cache (per QGIS build), so across sessions too.
        self._slots = {}
        self._slots_dirty = False
        # Class of the window being scanned (slots are only remembered
        # within a scan, where the widget's place is known).
        self._scan_window = None
        self._icons = {}
        self._pending = []
        self._theme = None
        self._icons_dir = None

    def apply(self, theme, icons_dir, main_window, colors=None, scale=studio_icons.SCALE, compact=False):
        """Show `theme`'s icons: the SVGs in `icons_dir`, or the icons
        composed from the masks in the theme's `colors` (normal, disabled
        and selected state, see icon_colors) at glyph `scale`, on `compact`
        (low-density) screens or not."""
        self._colors = colors
        self._compact_screens = compact
        if scale != self._scale:
            self._scale = scale
            self._masks = {}
        if self._theme is not None:
            self._retheme(theme, icons_dir)
            return
        self.restore()
        self._theme = theme
        self._icons = {}
        self._ours = {}
        self._names = {}
        self._icons_dir = icons_dir
        self._pixmaps = {}
        self._atlases = {}
        self._main_window = main_window
        self._extra_sizes = self._current_extra_sizes()
        self._png = self._pngs_usable()
        self._base_names = {
            QgsApplication.getThemeIcon(name).cacheKey(): name for name in studio_icons.ICON_MAP
        }
        self._names = dict(self._base_names)
        QTimer.singleShot(self.WARM_DELAY, self._request_reference)
        # Existing widgets: identify cheap matches now, the rest in idle
        # time. Hidden windows are left to the focus fallback and menus are
        # swapped when they are about to open, except the main window: QGIS
        # shows it only after loading the plugins, and left to the focus
        # fallback its toolbars would first show the theme's unsnapped
        # SVGs, then switch.
        for window in QApplication.topLevelWidgets():
            if window.isVisible() or isinstance(window, QMenu) or window is main_window:
                self._scan(window, deferred=True)
        if self._pending:
            QTimer.singleShot(0, self._drain)
        self._filter(main_window, self._CHILD_POLISHED)
        QGuiApplication.instance().focusWindowChanged.connect(self._on_focus_window)
        self._keep_tree_sizes()

    def _retheme(self, theme, icons_dir):
        """Switch from one Studio theme to another in place: every swapped
        icon goes straight to the new theme's version. Restoring the
        built-in icons first would update each action twice, and every
        update relays out the toolbars and menus that show it. Hooks and
        identified icons carry over unchanged."""
        self._compact()
        self._theme = theme
        self._icons = {}
        self._pixmaps = {}
        self._atlases = {}
        self._icons_dir = icons_dir
        self._extra_sizes = self._current_extra_sizes()
        self._png = self._pngs_usable()
        # Each setIcon repaints its toolbar or menu: suspend painting and
        # repaint every window once at the end.
        windows = [w for w in QApplication.topLevelWidgets() if w.isVisible() and w.updatesEnabled()]
        for window in windows:
            window.setUpdatesEnabled(False)
        try:
            self._retheme_icons(theme)
        finally:
            for window in windows:
                if not sip.isdeleted(window):
                    window.setUpdatesEnabled(True)
        self._keep_tree_sizes()

    def _keep_tree_sizes(self):
        """The panel trees' size again after a theme is applied: its
        stylesheet's own panel size (PANEL_ICON_RULES) is set again whenever
        Qt polishes them, now or once the events of the switch are done."""
        self._refresh_trees()
        QTimer.singleShot(0, self._refresh_trees)

    def _retheme_icons(self, theme):
        for action in self._watched:
            if not sip.isdeleted(action):
                new = self._rethemed(action.icon())
                if new is not None:
                    action.setIcon(new)
        for owner, kind, index, _icon in self._swapped:
            if not sip.isdeleted(owner) and self._valid(owner, kind, index):
                new = self._rethemed(self._get(owner, kind, index))
                if new is not None:
                    self._set(owner, kind, index, new)
        for root in self._scanned:
            if not sip.isdeleted(root):
                root.setProperty(self.PROPERTY, theme)
        for view, _original, _delegate in self._delegates.values():
            if not sip.isdeleted(view):
                view.viewport().update()

    def _rethemed(self, icon):
        """The current theme's version of one of our icons (None if `icon`
        is not one of ours, e.g. the application replaced it since)."""
        name = self._ours.get(icon.cacheKey())
        return None if name is None else self._icon(name)

    def use_pngs(self):
        """Masks were drawn: every icon handed out so far (drawn from the
        SVGs meanwhile, or pre-rendered for other screens) moves to its
        pixel-snapped version in place, with a single repaint."""
        if self._theme is not None and self._pngs_usable() != self._png:
            self._retheme(self._theme, self._icons_dir)

    def refresh_sizes(self):
        """Screens or QGIS's icon size changed: icons whose masks no longer
        cover every screen and size go back to the SVGs (sharp at any size,
        not stretched pixels) until the missing masks are drawn."""
        if self._theme is None:
            return
        self._refresh_trees()
        self._extra_sizes = self._current_extra_sizes()
        if self._pngs_usable() != self._png:
            self._retheme(self._theme, self._icons_dir)

    @property
    def mask_folders(self):
        return self._mask_folders

    @property
    def icons_dir(self):
        """The active theme's icon folder (None without a Studio theme)."""
        return self._icons_dir if self._theme is not None else None

    @property
    def scale(self):
        return self._scale

    def _current_extra_sizes(self):
        """QGIS's toolbar icon size, dialog page list size and the main panel
        trees' size (see _tree_size), as now set."""
        window = self._main_window
        toolbar = window.iconSize().width() if window is not None and not sip.isdeleted(window) else 24
        return toolbar, self._list_size(), self._tree_size()

    # Dialog page lists (Layer Properties, Data Source Manager...): 24 px
    # icons instead of QGIS's toolbar size plus 4 (28 px at the default 24).
    # (20 px let a 760 px Layer Properties dialog show all its pages without
    # scrolling, but read small; the lists scroll.) The Layer Styling and
    # Dev Tools rails share the list's name and keep their own size. Larger
    # icon size settings make them a step larger, as the panel trees
    # (TREE_STEPS).
    # The Options dialog (and others built like it) shows its pages in a
    # tree, mOptionsTreeView: the same size.
    PAGE_LISTS = frozenset({"mOptionsListWidget", "mOptListWidget", "mOptionsTreeView"})
    PAGE_LIST_ICON = 24
    RAILS = ("QgsLayerStylingWidget", "QgsDevToolsPanelWidget")

    def _list_size(self):
        """Icon size of dialog page lists, as set by _page_list."""
        return QgsApplication.scaleIconSize(self.PAGE_LIST_ICON) + self._size_step()

    def _size_step(self):
        """How much larger than at the default the lists and trees are for
        QGIS's toolbar icon size (TREE_STEPS)."""
        window = self._main_window
        toolbar = window.iconSize().width() if window is not None and not sip.isdeleted(window) else 24
        return next((px for limit, px in self.TREE_STEPS if toolbar <= limit), 16)

    # The main panel trees (Browser, Layers, Processing Toolbox): their
    # icons follow QGIS's toolbar icon size, which QGIS applies to toolbars
    # only, from the theme's own size for them (PANEL_ICON_RULES: 20 px,
    # QGIS's 16 on compact screens), a step larger per larger setting.
    PANEL_TREES = ("QgsBrowserTreeView", "QgsLayerTreeView", "QgsProcessingToolboxTreeView")
    TREE_STEPS = ((24, 0), (32, 4), (48, 8))  # (toolbar size up to, extra px); above: 16

    def _tree_size(self):
        """Icon size of the main panel trees for QGIS's toolbar icon size."""
        base = 16 if self._compact_screens else DOCK_ICON_SIZE
        return base + self._size_step()

    def _panel_tree(self, view):
        """Give a main panel tree the icon size of QGIS's icon size setting
        (see _tree_size); its own size is restored with the theme."""
        if not any(view.inherits(name) for name in self.PANEL_TREES):
            return
        size = self._tree_size()
        if id(view) not in self._trees:
            self._trees[id(view)] = (view, view.iconSize())
        if view.iconSize() != QSize(size, size):
            view.setIconSize(QSize(size, size))

    def _panel_toolbar(self, toolbar):
        """A panel's toolbar (Browser, Layers, Identify Results...): icons of
        at least DOCK_ICON_SIZE, a step larger per larger icon size setting
        (QGIS gives them 16 px at the default, small beside everything else),
        on every screen; never smaller than QGIS's own size for them. Its
        own size is restored with the theme."""
        parent = toolbar.parentWidget()
        while parent is not None and not isinstance(parent, QDockWidget):
            parent = parent.parentWidget()
        if parent is None:
            return
        size = DOCK_ICON_SIZE + self._size_step()
        if id(toolbar) not in self._panel_bars:
            self._panel_bars[id(toolbar)] = (toolbar, toolbar.iconSize())
        if toolbar.iconSize().width() < size:
            toolbar.setIconSize(QSize(size, size))

    def _panel_search(self, field):
        """A panel's search field (Processing Toolbox, Browser filter...)
        shows QGIS's magnifier at its start, the field reading as a search
        at a glance; QGIS's own setting comes back with the theme."""
        if id(field) in self._searches or field.property("showSearchIcon") is not False:
            return
        parent = field.parentWidget()
        while parent is not None and not isinstance(parent, QDockWidget):
            parent = parent.parentWidget()
        if parent is None:
            return
        self._searches[id(field)] = (field,)
        field.setProperty("showSearchIcon", True)

    def _refresh_trees(self):
        """QGIS's icon size changed: the panel trees, panel toolbars and the
        open dialogs' page lists follow."""
        for view, _size in list(self._trees.values()):
            if not sip.isdeleted(view):
                self._panel_tree(view)
        for toolbar, _size in list(self._panel_bars.values()):
            if not sip.isdeleted(toolbar):
                self._panel_toolbar(toolbar)
        size = self._list_size()
        for widget, _size in list(self._page_lists.values()):
            if not sip.isdeleted(widget) and widget.iconSize() != QSize(size, size):
                widget.setIconSize(QSize(size, size))

    def _page_list(self, widget):
        """Give a dialog page list its icon size (see PAGE_LISTS)."""
        if widget.objectName() not in self.PAGE_LISTS or id(widget) in self._page_lists:
            return
        parent = widget.parentWidget()
        for _ in range(6):
            if parent is None:
                break
            if any(parent.inherits(rail) for rail in self.RAILS):
                return
            parent = parent.parentWidget()
        size = self._list_size()
        self._page_lists[id(widget)] = (widget, widget.iconSize())
        widget.setIconSize(QSize(size, size))

    def needed_png_sizes(self):
        """(pixel size, line width) of the masks these screens need."""
        ratios = screen_ratios()
        return device_sizes(ratios, logical_sizes(ratios, self._extra_sizes))

    def _pngs_usable(self):
        """(screen ratios, logical sizes) when masks cover every size on
        every screen, else None: the SVGs are used until then."""
        if self._colors is None or not self._mask_folders:
            return None
        ratios = screen_ratios()
        sizes = logical_sizes(ratios, self._extra_sizes)
        if not missing_masks(self._mask_folders, device_sizes(ratios, sizes), self._scale):
            return ratios, sizes
        return None

    def _compact(self):
        """Forget deleted widgets, actions and the icons of closed dialogs,
        so bookkeeping, re-theming and restoring stay proportional to what
        is alive rather than to every dialog opened this session."""
        def alive(obj):
            return not sip.isdeleted(obj)

        self._swapped = [entry for entry in self._swapped if alive(entry[0])]
        self._scanned = [widget for widget in self._scanned if alive(widget)]
        self._filtered = [obj for obj in self._filtered if alive(obj)]
        self._docks = {id(obj) for obj in self._filtered if isinstance(obj, QDockWidget)}
        self._bars = {id(obj) for obj in self._filtered if isinstance(obj, (QToolBar, QMenuBar))}
        self._watched = {action: recheck for action, recheck in self._watched.items() if alive(action)}
        self._pickers = {key: edit for key, edit in self._pickers.items() if alive(edit)}
        for table in (self._stacks, self._menus, self._models, self._delegates, self._collapsibles, self._page_lists,
                      self._row_focus, self._rooms, self._relaxed, self._trees, self._panel_bars,
                      self._searches):
            for key in [key for key, entry in table.items() if not alive(entry[0])]:
                del table[key]
        self._names = dict(self._base_names)
        self._names.update(dict.fromkeys(self._ours))
        self._compact_at = max(self.COMPACT_MIN, 2 * (len(self._scanned) + len(self._swapped)))

    def _filter(self, obj, *types):
        """Watch `obj` for events of `types` (see _on_event), through the
        hub shared with the toolbar names."""
        self._hub.watch(obj, self, types, self._on_event)
        self._filtered.append(obj)

    # Feature pickers (expression builder > Feature, relation references):
    # QGIS writes black into their text field's palette whenever the feature
    # changes, which the stylesheet cannot override (dark text on a dark
    # field). The text colour is put back after each such change.
    PICKERS = ("QgsFeaturePickerWidget", "QgsFeatureListComboBox")

    def _hook_picker(self, edit):
        if id(edit) in self._pickers:
            return
        parent = edit.parentWidget()
        for _ in range(3):
            if parent is None:
                return
            if any(parent.inherits(name) for name in self.PICKERS):
                break
            parent = parent.parentWidget()
        else:
            return
        self._pickers[id(edit)] = edit
        self._filter(edit, self._PALETTE_CHANGE)
        self._fix_picker_text(edit)

    @staticmethod
    def _fix_picker_text(edit):
        text = QApplication.palette().color(QPalette.ColorRole.Text)
        palette = edit.palette()
        if palette.color(QPalette.ColorRole.Text) == QColor(Qt.GlobalColor.black) != text:
            palette.setColor(QPalette.ColorRole.Text, text)
            edit.setPalette(palette)

    def eventFilter(self, watched, event):  # pylint: disable=invalid-name
        """Menus about to open (a filter of their own, only while opening)."""
        if event.type() == self._SHOW and isinstance(watched, QMenu):
            self._menu_shown(watched)
        return False

    def _on_event(self, watched, event):
        """Events the hub passes on (only the types asked for in _filter)."""
        kind = event.type()
        if kind == self._ACTION_ADDED and isinstance(watched, (QToolBar, QMenuBar)):
            # Swap once the code adding the action has finished setting it
            # up (some set the icon after addAction).
            action = event.action()
            QTimer.singleShot(0, lambda action=action, bar=watched: self._action_added(bar, action))
        elif kind == self._SHOW and isinstance(watched, QToolButton):
            # A collapsible group box's collapse button (_hook_collapse).
            entry = self._collapsibles.get(id(watched.parentWidget()))
            if entry is not None:
                entry[1]()
        elif kind == self._LAYOUT_REQUEST and id(watched) in self._rooms:
            self._fit_room(watched)
        elif kind == self._PALETTE_CHANGE and id(watched) in self._pickers:
            self._fix_picker_text(watched)
        elif kind == self._CHILD_POLISHED:
            child = event.child()
            if child is not None and child.isWidgetType() and (
                not isinstance(watched, QStackedWidget) or watched.currentWidget() is child
            ):
                self._scan(child, deferred=False)
        return False

    # The status bar's CRS button: QGIS sets its icon again from its own
    # cached icon whenever the project's CRS changes.
    CRS_BUTTON = "mOntheFlyProjectionStatusButton"

    def _hook_crs(self, button):
        if self._crs_button is not None:
            return
        self._crs_button = button
        QgsProject.instance().crsChanged.connect(self._crs_changed)

    def _crs_changed(self):
        # After QGIS's own slot has set the button's icon again.
        QTimer.singleShot(0, self._reswap_crs)

    def _reswap_crs(self):
        button = self._crs_button
        if self._theme is not None and button is not None and not sip.isdeleted(button):
            self._swap(button, None, None, False)

    def _action_added(self, bar, action):
        """An action added to a scanned toolbar or menu bar: its icon, and
        on a toolbar the widget showing it. A widget added with addWidget()
        (the Identify Results panel's mode and settings buttons) comes as an
        action without an icon, its button never visited otherwise."""
        if self._theme is None or sip.isdeleted(bar) or sip.isdeleted(action):
            return
        self._swap(action, None, None, False)
        if not isinstance(bar, QToolBar):
            return
        widget = bar.widgetForAction(action)
        if widget is None or sip.isdeleted(widget):
            return
        types = self.ICON_TYPES
        for child in [widget, *widget.findChildren(QWidget)]:
            if isinstance(child, types):
                self._visit(child, False)

    def _on_focus_window(self, _window):
        widget = QApplication.activePopupWidget() or QApplication.activeWindow()
        if widget is not None:
            self._scan(widget, deferred=False)

    # ---- Identification ---------------------------------------------------

    @staticmethod
    def _serialized(icon):
        data = QByteArray()
        stream = QDataStream(data, QIODevice.OpenModeFlag.WriteOnly)
        stream << icon  # pylint: disable=pointless-statement
        return bytes(data)

    @staticmethod
    def _digest(icon):
        return hashlib.sha1(IconSwapper._serialized(icon)).hexdigest()

    # A built-in icon's file as an SVG icon stores it (UTF-16 text).
    _RESOURCE_FILE = re.compile(r":/images/(?:themes/default|icons)/([\w./ -]+?\.(?:svg|png))")

    def _match(self, icon):
        """The QGIS icon name of `icon` by its data: its fingerprint, or
        else the built-in file it names. Some QGIS widgets build their
        icons so that the data differs from the plain icon's (the layout
        designer's guide buttons), while still naming the file."""
        data = self._serialized(icon)
        name = self._reference().get(hashlib.sha1(data).hexdigest())
        if name is None:
            for start in (0, 1):
                text = data[start:].decode("utf-16-be", errors="ignore")
                for found in self._RESOURCE_FILE.finditer(text):
                    # QGIS writes some paths with a doubled slash
                    # (".../default//classification_methods/...").
                    found_name = found.group(1).lstrip("/")
                    if found_name in studio_icons.ICON_MAP:
                        return found_name
        return name

    # Bump when identification changes, so remembered answers (slots) made
    # by an earlier version are dropped (2: icons named by their file).
    MATCH_FORMAT = 2

    def _reference_key(self):
        names = "|".join(studio_icons.ICON_MAP)
        return f"{self.MATCH_FORMAT}|{Qgis.version()}|{qVersion()}|{hashlib.sha1(names.encode()).hexdigest()}"

    def _load_reference(self):
        """The fingerprint table from the disk cache (per QGIS/Qt build and
        icon map), or False when it has to be computed."""
        if self._reference_table is not None:
            return True
        if self._cache_checked:
            return False
        self._cache_checked = True
        if self._cache_file is None or not self._cache_file.exists():
            return False
        try:
            cached = json.loads(self._cache_file.read_text(encoding="utf-8"))
        except (OSError, ValueError):
            return False
        if cached.get("key") != self._reference_key() or "png_sizes" not in cached:
            return False
        self._reference_table = cached["digests"]
        self._png_signatures = {tuple(map(tuple, sig)) for sig in cached["png_sizes"]}
        slots = cached.get("slots")
        if isinstance(slots, dict):
            self._slots = {**slots, **self._slots}
        return True

    def _save_reference(self):
        """Write the fingerprint table and the remembered slots to disk."""
        self._slots_dirty = False
        if self._cache_file is None or self._reference_table is None:
            return
        try:
            write_atomic(self._cache_file, json.dumps({
                "key": self._reference_key(),
                "digests": self._reference_table,
                "png_sizes": sorted(self._png_signatures),
                "slots": self._slots,
            }).encode("utf-8"))
        except OSError:
            pass

    SLOT_LIMIT = 20000

    def _slot(self, owner, kind, index):
        """A stable name for an icon slot within the window being scanned
        (None outside a scan, or for unnamed widgets and model items):
        Designer gives every widget and action a name unique in its form."""
        if self._scan_window is None or kind == "model":
            return None
        name = owner.objectName()
        if not name:
            return None
        parent = owner.parent()
        parent_name = parent.objectName() if parent is not None else ""
        return f"{self._scan_window}|{parent_name}|{name}|{kind or ''}|{'' if index is None else index}"

    def _remember_slot(self, slot, name):
        if len(self._slots) >= self.SLOT_LIMIT:
            self._slots = {}
        self._slots[slot] = name
        if not self._slots_dirty:
            self._slots_dirty = True
            # Written once things are quiet, not per dialog.
            QTimer.singleShot(15000, self._save_reference)

    def _reference_step(self, count):
        """Fingerprint up to `count` more built-in icons; True when done."""
        if self._reference_queue is None:
            self._reference_queue = list(studio_icons.ICON_MAP)
            self._reference_partial = {}
            self._png_signatures = set()
        for name in self._reference_queue[:count]:
            # Check first: QIcon on a missing resource logs a Qt warning,
            # which QGIS surfaces in the message bar.
            source = self._source(name)
            if source is None:
                continue
            icon = QIcon(source)
            self._reference_partial.setdefault(self._digest(icon), name)
            if not source.lower().endswith(".svg"):
                self._png_signatures.add(self._signature(icon))
        del self._reference_queue[:count]
        if self._reference_queue:
            return False
        self._reference_table = self._reference_partial
        self._reference_queue = self._reference_partial = None
        self._save_reference()
        return True

    def _request_reference(self):
        """Start the idle-time fingerprinting now (if it is not running or
        done): WARM_DELAY after the theme is applied, or earlier when a
        panel meets an icon only the fingerprints can identify."""
        if not self._warming and self._theme is not None and self._reference_table is None:
            self._warming = True
            QTimer.singleShot(0, self._warm_reference)

    def _warm_reference(self):
        """Compute the fingerprint table a batch at a time between events;
        once ready, the delegated panels redraw with the icons they were
        drawn without meanwhile."""
        if self._theme is None:
            self._warming = False
            return
        if self._load_reference() or self._reference_step(self.WARM_BATCH):
            self._warming = False
            for view, _original, _delegate in self._delegates.values():
                if not sip.isdeleted(view):
                    view.viewport().update()
            return
        QTimer.singleShot(0, self._warm_reference)

    def _reference(self):
        """Fingerprints of the built-in icons (finishing them now if the
        idle-time warm-up has not yet)."""
        if not self._load_reference():
            self._reference_step(len(studio_icons.ICON_MAP))
        return self._reference_table

    @staticmethod
    def _signature(icon):
        return tuple(sorted((size.width(), size.height()) for size in icon.availableSizes()))

    def _replacement(self, icon, deferred=False, slot=None):
        """Our icon for `icon`, None if it has none, or _UNKNOWN when it
        needs the (slower) data comparison and `deferred` is set. `slot`
        (see _slot) remembers what the icon in that place turned out to be:
        only for icons without pixmaps, which the comparison fingerprints."""
        if icon.isNull():
            return None
        key = icon.cacheKey()
        if self._style == "classic":
            # QGIS's own icon, from its resources: the copy QGIS keeps in
            # its cache can still show the previous style's drawing after a
            # switch at runtime. Only icons QGIS looked up by name.
            name = self._base_names.get(key)
            return None if name is None else self._classic_icon(name)
        name = self._names.get(key, self._UNKNOWN)
        if name is self._UNKNOWN:
            if slot is not None and not icon.availableSizes():
                self._load_reference()
                name = self._slots.get(slot, self._UNKNOWN)
            else:
                slot = None
        if name is self._UNKNOWN:
            if deferred:
                return self._UNKNOWN
            name = self._identify(icon)
            if slot is not None:
                self._remember_slot(slot, name)
        self._names[key] = name
        if name is None:
            return None
        return self._icon(name)

    def _png_signature_set(self):
        """Pixmap size signatures of the built-in PNG icons: from the
        fingerprint table once it is ready, else from just those icons
        (two dozen small files), so turning down a pixmap icon never makes
        the whole table be built on the spot."""
        if self._load_reference():
            return self._png_signatures
        if self._quick_png_signatures is None:
            signatures = set()
            for name in studio_icons.ICON_MAP:
                if not name.lower().endswith(".svg"):
                    source = self._source(name)
                    if source is not None:
                        signatures.add(self._signature(QIcon(source)))
            self._quick_png_signatures = signatures
        return self._quick_png_signatures

    def _identify(self, icon):
        """The QGIS icon name of `icon` by its data (None if not ours)."""
        # Pixmap-based icons (symbol previews, colour swatches, legend
        # items) list their pixmap sizes; fingerprinting them would
        # PNG-encode every pixmap. Only the few built-in PNG icons share
        # such a signature, so anything else is not ours to replace.
        signature = self._signature(icon)
        if signature and signature not in self._png_signature_set():
            return None
        return self._match(icon)

    def keyed_icon(self, icon):
        """Our version of an icon the Browser or Layers delegate draws,
        identified by the icon itself, or None to keep it. Runs on every
        paint of every row, so it never does slow work: pixmap icons (layer
        symbols, legend items, the editing pencil composited onto a layer
        icon) are new on every paint and never one of the QGIS icons these
        panels show, so they are turned down at once, not fingerprinted;
        other unknown icons wait for the idle-time fingerprints (the panel
        redraws once they are ready) instead of computing them mid-paint."""
        if self._theme is None or icon.isNull() or self._style == "classic":
            return None
        key = icon.cacheKey()
        name = self._names.get(key, self._UNKNOWN)
        if name is self._UNKNOWN:
            name = self._key_names.get(key, self._UNKNOWN)
        if name is self._UNKNOWN:
            if icon.availableSizes():
                return None
            if not self._load_reference():
                self._request_reference()
                return None
            name = self._match(icon)
            if len(self._key_names) > 4096:
                self._key_names.clear()
            self._key_names[key] = name
        return None if name is None else self._icon(name)

    def row_icon(self, row, icon, group=False):
        """Our version of the icon a delegated view draws for `row` (a
        hashable row identity), or None to keep it. Identified once per row,
        never by computing fingerprints mid-paint (see keyed_icon). Group
        rows that only repeat the provider's or the generic tool icon get a
        toolbox, so groups and tools are told apart at a glance."""
        if self._theme is None or self._style == "classic":
            return None
        row = (row, group)
        name = self._view_names.get(row, self._UNKNOWN)
        if name is self._UNKNOWN:
            name = self._names.get(icon.cacheKey(), self._UNKNOWN)
            if name is self._UNKNOWN:
                if not self._load_reference():
                    self._request_reference()
                    return None
                name = self._identify(icon)
            if group and name in self.GENERIC_ICONS:
                name = self.GROUP_ICON
            if len(self._view_names) > 8192:
                self._view_names.clear()
            self._view_names[row] = name
        return None if name is None else self._icon(name)

    def _delegate_view(self, view, by_row=True, folders=True, soften=False):
        """Draw `view`'s rows with our icons (only over Qt's plain
        delegate, or the Layers panel's, so no custom drawing is lost)."""
        if id(view) in self._delegates:
            return
        original = view.itemDelegate()
        kind = None if original is None else original.metaObject().className()
        if kind == "QStyledItemDelegate":
            delegate = _IconDelegate(self, view, by_row, folders, soften)
        elif kind == "QgsLayerTreeViewItemDelegate":
            delegate = _LayerTreeDelegate(self, view, original)
        else:
            return
        view.setItemDelegate(delegate)
        self._delegates[id(view)] = (view, original, delegate)

    def _classic_icon(self, name):
        """QGIS's built-in icon for a QGIS icon name, None if it has none."""
        if name not in self._classics:
            path = f":/images/themes/default/{name}"
            self._classics[name] = QIcon(path) if QFile.exists(path) else None
        return self._classics[name]

    def _icon(self, name):
        """Our icon for a QGIS icon name, in the active theme."""
        if name not in self._icons:
            ours = None
            if self._png:
                # Every pre-rendered size readable: an icon shown 1:1 at any
                # size (SharpIconEngine), never one Qt resamples.
                ratios, sizes = self._png
                if all(self._pixmap(name, round(size * ratio), state, ratio) is not None
                       for ratio in ratios for size in sizes for state, _mode in ICON_STATES):
                    ours = QIcon(SharpIconEngine(self, name))
            if ours is None:
                # The SVGs (before the PNGs are drawn, or if an atlas cannot
                # be read): sharp at any size.
                ours = QIcon(str(self._icons_dir / icon_file(name)))
                for state, mode in ICON_STATES[1:]:
                    ours.addFile(str(state_path(self._icons_dir, name, state)), QSize(), mode)
            self._icons[name] = ours
            # Never examine our own icons again.
            self._names[ours.cacheKey()] = None
            self._ours[ours.cacheKey()] = name
        return self._icons[name]

    def png_sizes(self):
        """The logical sizes pre-rendered now (none while the SVGs are used)."""
        return self._png[1] if self._png else ()

    def exact_pixmap(self, name, size, state, ratio):
        """Icon `name` at exactly `size` device pixels for a screen at
        `ratio` (see SharpIconEngine): cut from its atlas when one covers the
        size, else drawn for it once and kept. None without a theme."""
        if self._theme is None or self._colors is None or name not in studio_icons.ICON_MAP:
            return None
        if self._png:
            ratios, sizes = self._png
            if ratio in ratios and any(round(logical * ratio) == size for logical in sizes):
                return self._pixmap(name, size, state, ratio)
        spec = studio_icons.ICON_MAP[name]
        key = (spec, size, state, ratio)
        pixmap = self._pixmaps.get(key)
        if pixmap is None:
            width = studio_icons.screen_stroke_px(ratio)
            mask_key = (spec, size, width, self._scale)
            masks = self._one_masks.get(mask_key)
            if masks is None:
                masks = render_one(spec, size, width, self._scale)
                self._one_masks[mask_key] = masks
            colors = self._colors[[name for name, _mode in ICON_STATES].index(state)]
            pixmap = compose_atlas(masks, colors, self._style == "color", state == "disabled")
            pixmap.setDevicePixelRatio(ratio)
            self._pixmaps[key] = pixmap
        return pixmap

    def _pixmap(self, name, size, state, ratio):
        """One icon cut from its atlas (None if the atlas is unreadable)."""
        spec = studio_icons.ICON_MAP[name]
        key = (spec, size, state, ratio)
        pixmap = self._pixmaps.get(key)
        if pixmap is None:
            width = studio_icons.screen_stroke_px(ratio)
            atlas_key = (size, width, state)
            if atlas_key not in self._atlases:
                masks = self._load_masks(size, width)
                colors = self._colors[[name for name, _mode in ICON_STATES].index(state)]
                self._atlases[atlas_key] = None if masks is None else compose_atlas(
                    masks, colors, self._style == "color", state == "disabled")
            atlas = self._atlases[atlas_key]
            if not self._atlas_index:
                self._atlas_index = atlas_index()
            index = self._atlas_index.get(spec)
            if atlas is None or index is None:
                return None
            pixmap = atlas.copy(atlas_cell(index, size))
            pixmap.setDevicePixelRatio(ratio)
            self._pixmaps[key] = pixmap
        return pixmap

    def _load_masks(self, size, width):
        """The masks of one size (read once, shared by every theme)."""
        key = (size, width, self._scale)
        masks = self._masks.get(key)
        if masks is None:
            folder = find_masks(self._mask_folders, *key)
            masks = None if folder is None else load_masks(folder, *key)
            if masks is not None:
                self._masks[key] = masks
        return masks

    def _builtin(self, icon):
        """The stock icon for one of our icons (used when restoring)."""
        name = self._ours.get(icon.cacheKey())
        source = None if name is None else self._source(name)
        return None if source is None else QIcon(source)

    def _source(self, name):
        """Where QGIS loads the stock icon `name` from (None if missing).
        Checked first: QIcon on a missing file logs a Qt warning, which QGIS
        surfaces in the message bar."""
        if QFile.exists(self.RESOURCES + name):
            return self.RESOURCES + name
        elsewhere = studio_icons.RESOURCE_PATHS.get(name)
        if elsewhere is not None and QFile.exists(elsewhere):
            return elsewhere
        external = studio_icons.EXTERNAL.get(name)
        if external is not None:
            path = Path(QgsApplication.pkgDataPath()) / external
            if path.exists():
                return str(path)
        return None

    # ---- Applying ---------------------------------------------------------

    # Icon slots: (None, None) is the owner's own icon, ("row", i) a list
    # row, ("tab", i) a tab, ("item", i) a combo box item, ("model", p) the
    # item at persistent index p of a QStandardItemModel.
    @staticmethod
    def _valid(owner, kind, index):
        if kind is None:
            return True
        if kind == "model":
            return index.isValid()
        return index < owner.count()

    @classmethod
    def _get(cls, owner, kind, index):
        if kind is None:
            return owner.icon()
        if not cls._valid(owner, kind, index):
            return QIcon()
        if kind == "model":
            icon = owner.data(QModelIndex(index), cls._DECORATION)
            return icon if isinstance(icon, QIcon) else QIcon()
        if kind == "row":
            return owner.item(index).icon()
        if kind == "tab":
            return owner.tabIcon(index)
        return owner.itemIcon(index)

    @classmethod
    def _set(cls, owner, kind, index, icon):
        if kind is None:
            owner.setIcon(icon)
        elif kind == "model":
            owner.setData(QModelIndex(index), icon, cls._DECORATION)
        elif kind == "row":
            owner.item(index).setIcon(icon)
        elif kind == "tab":
            owner.setTabIcon(index, icon)
        else:
            owner.setItemIcon(index, icon)

    def _swap(self, owner, kind, index, deferred, slot=None):
        """Swap one icon slot; True when it shows (or is queued to show)
        one of our icons."""
        if self._theme is None or sip.isdeleted(owner):
            return False
        icon = self._get(owner, kind, index)
        key = icon.cacheKey()
        if key in self._ours:
            return True
        if slot is None and key not in self._names:
            slot = self._slot(owner, kind, index)
        new = self._replacement(icon, deferred, slot)
        if new is self._UNKNOWN:
            self._pending.append((owner, kind, index, slot))
            return True
        if new is None:
            return False
        if isinstance(owner, QAction):
            owner.setIcon(new)
            self._watch(owner)
            return True
        self._swapped.append((owner, kind, index, icon))
        self._set(owner, kind, index, new)
        return True

    def _scan(self, root, deferred):
        """Swap every icon in a widget tree; each tree is scanned once.

        Only the current page of each stacked widget is entered (dialogs
        and panels keep most pages hidden); other pages are scanned when
        they become current. Qt returns the candidates parents first, so a
        stacked widget is always seen before the pages it excludes."""
        if self._theme is None or sip.isdeleted(root) or root.property(self.PROPERTY) == self._theme:
            return
        if len(self._scanned) + len(self._swapped) >= self._compact_at:
            self._compact()
        self._mark(root)
        if isinstance(root, QDialog) and root.isWindow():
            self._hold_room(root)
        # All widgets, filtered here: faster than findChildren() with a
        # tuple of types, which PyQt matches type by type. The full list
        # stays referenced during the scan: its Python wrappers make the
        # parent walks below cheap, and keep every id() in them unique.
        types = self.ICON_TYPES
        everything = root.findChildren(QWidget)
        widgets = [widget for widget in everything if isinstance(widget, types)]
        if isinstance(root, types):
            widgets.insert(0, root)
        # Widgets on a skipped page (a stacked widget's other pages) are
        # found by walking up their parents, each answer remembered (id ->
        # skipped?), instead of listing each page's widgets again: most of
        # a large dialog's widgets are on its hidden pages.
        hidden = {id(root): False}
        outer = self._scan_window
        self._scan_window = root.window().metaObject().className()
        try:
            for widget in widgets:
                if len(hidden) > 1 and self._on_skipped_page(widget, hidden):
                    continue
                try:
                    self._visit(widget, deferred)
                except Exception as error:  # pylint: disable=broad-except
                    # A plugin's widget that breaks Qt's API (a method
                    # shadowed by an attribute...) keeps its own icons;
                    # the rest of the window is still themed.
                    self._visit_failed(widget, error)
                if isinstance(widget, QStackedWidget):
                    self._hook_stack(widget)
                    current = widget.currentWidget()
                    for index in range(widget.count()):
                        page = widget.widget(index)
                        if page is current and page.property(self.PROPERTY) != self._theme:
                            self._mark(page)
                        else:
                            hidden[id(page)] = True
        finally:
            self._scan_window = outer
        del everything

    def _visit_failed(self, widget, error):
        """Log a widget _visit could not handle, once per class."""
        name = type(widget).__name__
        if name in self._failed_classes:
            return
        self._failed_classes.add(name)
        QgsMessageLog.logMessage(
            f"Skipped icons of a {name} ({widget.objectName() or 'unnamed'}): {error!r}",
            LOG_TAG, Qgis.MessageLevel.Warning,
        )

    @staticmethod
    def _on_skipped_page(widget, hidden):
        chain = []
        answer = False
        while widget is not None:
            known = hidden.get(id(widget))
            if known is not None:
                answer = known
                break
            chain.append(id(widget))
            widget = widget.parentWidget()
        for key in chain:
            hidden[key] = answer
        return answer

    def _mark(self, widget):
        widget.setProperty(self.PROPERTY, self._theme)
        self._scanned.append(widget)

    def _hook_stack(self, stacked):
        """Scan pages when they are shown, and pages added later (panels
        build them on demand) before they are first shown."""
        if id(stacked) in self._stacks:
            return

        def current_changed(index, stacked=stacked):
            if self._theme is not None and not sip.isdeleted(stacked):
                page = stacked.widget(index)
                if page is not None:
                    self._scan(page, deferred=False)
                    self._relax_page(stacked)

        stacked.currentChanged.connect(current_changed)
        self._stacks[id(stacked)] = (stacked, current_changed)
        self._filter(stacked, self._CHILD_POLISHED)
        self._relax_page(stacked)

    _MINIMUM_EXPANDING = QSizePolicy.Policy.MinimumExpanding

    def _relax_page(self, stacked):
        """Option dialogs size their page area to the current page. A page
        whose width policy is MinimumExpanding (Layer Properties >
        Diagrams) makes its preferred width, ~800 px, a minimum, so the
        page list cannot be widened in a smaller window. Expanding keeps
        the page growing while its minimum is what it really needs; QGIS
        sets the policy again on each page change, so this follows it."""
        if stacked.objectName() != "mOptionsStackedWidget":
            return
        page = stacked.currentWidget()
        if page is None:
            return
        policy = page.sizePolicy()
        if policy.horizontalPolicy() == self._MINIMUM_EXPANDING:
            self._relaxed[id(page)] = (page,)
            policy.setHorizontalPolicy(QSizePolicy.Policy.Expanding)
            page.setSizePolicy(policy)

    def _visit(self, widget, deferred):
        """Swap the icons one widget shows itself (not its children).
        QGIS classes are matched with inherits(), not isinstance(): a QGIS
        widget created in C++ (the Processing Toolbox since QGIS 4.x) can
        reach Python as its Qt base class (QTreeView, QLineEdit)."""
        if isinstance(widget, QToolButton):
            if widget.objectName() == self.CRS_BUTTON:
                self._hook_crs(widget)
            action = widget.defaultAction()
            if action is not None:
                self._swap(action, None, None, deferred)
            else:
                self._swap(widget, None, None, deferred)
                # A collapsible group box's collapse button is a tool button.
                self._hook_collapse(widget)
                self._hook_toggle(widget)
            # Drop-down choices (align, distribute, export...): actions added
            # to the button itself, or a menu outside the scanned tree.
            for extra in widget.actions():
                if extra is not action:
                    self._swap(extra, None, None, deferred)
            # menu_of, not .menu(): plugins may shadow the method.
            menu = menu_of(widget) or menu_of(action)
            if menu is not None:
                self._hook_menu(menu)
                # Mode buttons (snapping type, overlap...): QGIS later makes
                # one of these choices the button's default action, so swap
                # them now rather than only when the menu first opens.
                for choice in menu.actions():
                    self._swap(choice, None, None, deferred)
        elif isinstance(widget, QMenu):
            self._hook_menu(widget)
        elif isinstance(widget, (QToolBar, QMenuBar)):
            if isinstance(widget, QToolBar):
                self._panel_toolbar(widget)
            for action in widget.actions():
                self._swap(action, None, None, deferred)
            if id(widget) not in self._bars:
                self._bars.add(id(widget))
                self._filter(widget, self._ACTION_ADDED)
        elif isinstance(widget, QAbstractButton):
            self._swap(widget, None, None, deferred)
        elif isinstance(widget, QListWidget):
            self._page_list(widget)
            self._rows(widget, "row", deferred)
        elif isinstance(widget, QComboBox):
            if widget.objectName() == self.THEME_COMBO:
                self._sort_themes(widget)
            self._rows(widget, "item", deferred)
        elif isinstance(widget, QTabBar):
            for index in range(widget.count()):
                self._swap(widget, "tab", index, deferred)
        elif widget.inherits("QgsFilterLineEdit"):
            # Embedded actions (clear, search). Spin boxes' editors are
            # skipped: big dialogs hold hundreds of them.
            if not isinstance(widget.parent(), QAbstractSpinBox):
                self._panel_search(widget)
                for action in widget.actions():
                    self._swap(action, None, None, deferred)
                self._hook_picker(widget)
        elif isinstance(widget, QDockWidget):
            # Panels may get (or replace) their contents after the window
            # was scanned.
            if id(widget) not in self._docks:
                self._docks.add(id(widget))
                self._filter(widget, self._CHILD_POLISHED)
        elif isinstance(widget, QAbstractItemView):
            if isinstance(widget, QTreeView):
                self._hide_row_focus(widget)
                self._panel_tree(widget)
                self._page_list(widget)
            if widget.inherits("QgsProcessingToolboxTreeView"):
                self._delegate_view(widget)
                # Every row has the same height (theme rule): let Qt measure
                # one row instead of each, when expanding and scrolling. (Not
                # the Browser: it is filled lazily, and a row measured while
                # it is still empty collapses every row to nothing.)
                widget.setUniformRowHeights(True)
            elif widget.inherits("QgsBrowserTreeView") or widget.inherits("QgsLayerTreeView"):
                self._delegate_view(widget, by_row=False)
            elif widget.objectName() == "mFieldsList":
                # Layer Properties > Fields: QGIS's fixed row tint, softened.
                self._delegate_view(widget, folders=False, soften=True)
            elif widget.model() is not None and widget.model().inherits("QgsHistoryEntryProxyModel"):
                # Processing History: each entry shows its algorithm's icon,
                # which QGIS cached before the theme was registered.
                self._delegate_view(widget, folders=False)
            model = widget.model()
            while isinstance(model, QAbstractProxyModel):
                model = model.sourceModel()
            # Only navigation-style lists and settings trees (a name column
            # and at most a value beside it, few rows, e.g. the Options page
            # tree, Options > Processing and the model designer's Inputs);
            # wider data tables are skipped outright. Only the first
            # column's icons are looked at. A combo box's popup view shares
            # the model already hooked by _rows.
            if (
                (isinstance(model, QStandardItemModel) or isinstance(widget, QTreeWidget))
                and id(model) not in self._models
                and model.columnCount() <= 2
                and model.rowCount() <= self.MODEL_LIMIT
            ):
                self._model_items(model, deferred)

    _LAYOUT_REQUEST = QEvent.Type.LayoutRequest

    def _hold_room(self, dialog):
        """Dialogs QGIS gives a fixed minimum size suited to its own,
        smaller controls (Layout Manager: 300 px for 335 px of contents
        with the theme's 28 px fields): Qt then squeezes rows into each
        other instead of growing the window. Such a dialog's minimum is
        raised to what its contents need whenever its layout changes
        (choosing a template shows another row), never below QGIS's own,
        and only in the sizes QGIS fixed.

        Option dialogs (Layer Properties...) are left alone: their pages
        scroll, and following each page's height would resize the window on
        every page change (on Wayland, each change is also a request to the
        compositor, which can stall moving the window).

        Other plugins' dialogs are Python subclasses that often shadow Qt
        methods with attributes (self.layout = QVBoxLayout()), so the
        dialog's methods are called through QWidget, never the instance."""
        own = QWidget.minimumSize(dialog)
        if (QWidget.layout(dialog) is None or id(dialog) in self._rooms or (own.width() == 0 and own.height() == 0)
                or QWidget.findChild(dialog, QStackedWidget, "mOptionsStackedWidget") is not None):
            return
        self._rooms[id(dialog)] = (dialog, own)
        self._filter(dialog, self._LAYOUT_REQUEST)
        self._fit_room(dialog)

    def _fit_room(self, dialog):
        entry = self._rooms.get(id(dialog))
        if entry is None or sip.isdeleted(dialog):
            return
        own = entry[1]
        need = dialog.minimumSizeHint()  # a virtual: a dialog's own override counts
        screen = QWidget.screen(dialog)
        limit = screen.availableGeometry().size() if screen is not None else need
        width = max(own.width(), min(need.width(), limit.width())) if own.width() else QWidget.minimumWidth(dialog)
        height = max(own.height(), min(need.height(), limit.height())) if own.height() else QWidget.minimumHeight(dialog)
        if (width, height) != (QWidget.minimumWidth(dialog), QWidget.minimumHeight(dialog)):
            QWidget.setMinimumSize(dialog, width, height)

    def _hide_row_focus(self, tree):
        """Trees showing focus across all columns (renderer categories,
        ranges...) draw that frame without naming the tree to the style, so
        the stylesheet cannot turn it off: a native white frame around the
        current row. Rows stay selected whole; the frame goes while the
        theme is shown."""
        if tree.allColumnsShowFocus() and id(tree) not in self._row_focus:
            self._row_focus[id(tree)] = (tree,)
            tree.setAllColumnsShowFocus(False)

    def _hook_collapse(self, button):
        """The collapse button of a collapsible group box: QGIS keeps its
        own expand and collapse icons and sets one of them on every open
        and close, and again when the box is shown (after it was scanned,
        e.g. Layer Styling > Layer Rendering), which would bring the
        built-in arrow back. Swap the button again after each change and
        each show (once QGIS has set its icon)."""
        box = button.parentWidget()
        if box is None or id(box) in self._collapsibles or not box.inherits("QgsCollapsibleGroupBoxBasic"):
            return
        if not hasattr(box, "collapsedStateChanged"):
            # Group boxes from .ui files reach Python as plain QGroupBox.
            try:
                box = sip.cast(box, QgsCollapsibleGroupBoxBasic)
            except (TypeError, RuntimeError):
                return

        def reswap(_collapsed=None, button=button):
            if self._theme is None or sip.isdeleted(button):
                return
            new = self._replacement(button.icon())
            if new is not None:
                button.setIcon(new)

        def changed(_collapsed=None):
            QTimer.singleShot(0, reswap)

        box.collapsedStateChanged.connect(changed)
        self._collapsibles[id(box)] = (box, changed)
        self._filter(button, self._SHOW)

    def _hook_toggle(self, button):
        """Swap a button's icon again whenever it is clicked: QGIS gives
        some another icon of its own each time (the status bar's
        coordinate/extent toggle)."""
        if id(button) in self._toggles:
            return

        def reswap(button=button):
            if self._theme is not None and not sip.isdeleted(button):
                self._swap(button, None, None, False)

        def clicked(_checked=False):
            QTimer.singleShot(0, reswap)

        button.clicked.connect(clicked)
        self._toggles[id(button)] = (button, clicked)

    @staticmethod
    def _sort_themes(combo):
        """Alphabetical theme list, so the Studio themes sit together. The
        selection is kept and no change signal is sent (QGIS would treat it
        as a theme choice)."""
        current = combo.currentText()
        names = sorted((combo.itemText(i) for i in range(combo.count())), key=str.casefold)
        if names == [combo.itemText(i) for i in range(combo.count())]:
            return
        blocked = combo.blockSignals(True)
        try:
            combo.clear()
            combo.addItems(names)
            combo.setCurrentIndex(max(0, combo.findText(current)))
        finally:
            combo.blockSignals(blocked)

    def _hook_menu(self, menu):
        """Swap a menu's icons right before it opens, not at startup. The
        swap happens on the Show event, after every aboutToShow handler, so
        actions QGIS (re)creates there are covered too; the event filter is
        installed only while the menu opens, not for every hover event."""
        if not isinstance(menu, QMenu) or id(menu) in self._menus:
            return

        def about_to_show(menu=menu):
            if self._theme is not None and not sip.isdeleted(menu):
                menu.installEventFilter(self)

        menu.aboutToShow.connect(about_to_show)
        self._menus[id(menu)] = (menu, about_to_show)

    def _menu_shown(self, menu):
        menu.removeEventFilter(self)
        if self._theme is None:
            return
        for action in menu.actions():
            self._swap(action, None, None, False)
            submenu = menu_of(action)
            if submenu is not None:
                self._hook_menu(submenu)

    def _rows(self, widget, kind, deferred):
        """Swap a list's or combo box's row icons. Rows added later are
        watched only where a row shows one of our icons, or none is there
        yet (filled later): data lists (fields, units, layers...) then cost
        no Python call per row inserted."""
        count = widget.count()
        ours = False
        for index in range(count):
            ours = self._swap(widget, kind, index, deferred) or ours
        model = widget.model()
        if id(model) in self._models or (count and not ours):
            return

        def inserted(_parent, first, last, widget=widget, kind=kind):
            if self._theme is None or sip.isdeleted(widget):
                return
            for index in range(first, last + 1):
                self._swap(widget, kind, index, False)

        model.rowsInserted.connect(inserted)
        self._models[id(model)] = (model, inserted)

    def _model_items(self, model, deferred):
        """Swap the item icons of a small QStandardItemModel or tree widget,
        and of rows added to it later (watched as in _rows)."""
        found = False
        # Level by level, so every top-level row (a settings group) is
        # swapped before the budget goes to one group's many children
        # (Options > Processing > Menus holds a row per algorithm).
        level = [QModelIndex()]
        budget = self.MODEL_LIMIT
        while level and budget > 0:
            below = []
            for parent in level:
                for row in range(model.rowCount(parent)):
                    if budget <= 0:
                        break
                    budget -= 1
                    index = model.index(row, 0, parent)
                    if isinstance(model.data(index, self._DECORATION), QIcon):
                        if self._swap(model, "model", QPersistentModelIndex(index), deferred):
                            found = True
                    if model.hasChildren(index):
                        below.append(index)
            level = below
        if model.rowCount() and not found:
            return

        def inserted(parent, first, last, model=model):
            if self._theme is None or sip.isdeleted(model):
                return
            for row in range(first, last + 1):
                index = model.index(row, 0, parent)
                if isinstance(model.data(index, self._DECORATION), QIcon):
                    self._swap(model, "model", QPersistentModelIndex(index), False)

        model.rowsInserted.connect(inserted)
        self._models[id(model)] = (model, inserted)

    def _drain(self):
        """Identify queued icons a batch at a time between events."""
        if self._theme is None:
            self._pending = []
            return
        batch, self._pending = self._pending[:self.BATCH], self._pending[self.BATCH:]
        for owner, kind, index, slot in batch:
            self._swap(owner, kind, index, False, slot)
        if self._pending:
            QTimer.singleShot(0, self._drain)

    @property
    def style(self):
        return self._style

    def set_style(self, style):
        """The icon style (ICON_STYLES) of the next apply()."""
        self._style = style
        self._atlases = {}
        self._pixmaps = {}

    def swap_action(self, action):
        """Our icon for an action's QGIS icon now, not once a menu showing
        it is first opened: the ribbon shows commands of menus that never
        open (QGIS sets some, New Report's, from its resources)."""
        self._swap(action, None, None, False)

    def themed_icon(self, name):
        """Our icon for a QGIS icon name (an ICON_MAP name) in the active
        theme, or None (no theme, QGIS's own icons, or a name we do not
        draw)."""
        if self._theme is None or self._style == "classic" or name not in studio_icons.ICON_MAP:
            return None
        return self._icon(name)

    def adopt(self, action, name):
        """Give an action QGIS gives no icon (a menu-only command on the
        ribbon) our icon `name` (an ICON_MAP name), re-themed like the
        others; True when it got it."""
        if (self._theme is None or self._style == "classic" or name not in studio_icons.ICON_MAP
                or not action.icon().isNull()):
            return False
        action.setIcon(self._icon(name))
        self._watch(action)
        return True

    def _watch(self, action):
        """QGIS re-sets some action icons from its cache later; swap again
        whenever that happens. `changed` also fires on every enable,
        disable and check (on each selection or layer change, for hundreds
        of actions), so the common case, still our icon, returns at once."""
        if action in self._watched:
            return

        def recheck(action=action):
            if self._theme is None or sip.isdeleted(action):
                return
            icon = action.icon()
            if icon.cacheKey() in self._ours:
                return
            new = self._replacement(icon)
            if new is not None:
                action.setIcon(new)

        action.changed.connect(recheck)
        self._watched[action] = recheck

    def restore(self):
        if self._theme is not None:
            QGuiApplication.instance().focusWindowChanged.disconnect(self._on_focus_window)
        if self._slots_dirty:
            self._save_reference()
        self._theme = None
        self._warming = False
        self._pending = []
        for obj in self._filtered:
            self._hub.unwatch(obj, self)
        self._filtered = []
        self._docks = set()
        if self._crs_button is not None:
            try:
                QgsProject.instance().crsChanged.disconnect(self._crs_changed)
            except (TypeError, RuntimeError):
                pass
            self._crs_button = None
        self._bars = set()
        for stacked, current_changed in self._stacks.values():
            if not sip.isdeleted(stacked):
                stacked.currentChanged.disconnect(current_changed)
        self._stacks = {}
        for menu, about_to_show in self._menus.values():
            if not sip.isdeleted(menu):
                menu.aboutToShow.disconnect(about_to_show)
                menu.removeEventFilter(self)
        self._menus = {}
        for view, original, delegate in self._delegates.values():
            if not sip.isdeleted(view):
                view.setItemDelegate(original)
                view.viewport().update()
            if not sip.isdeleted(delegate):
                delegate.deleteLater()
        self._delegates = {}
        self._view_names = {}
        self._key_names = {}
        for model, inserted in self._models.values():
            if not sip.isdeleted(model):
                model.rowsInserted.disconnect(inserted)
        self._models = {}
        for box, changed in self._collapsibles.values():
            if not sip.isdeleted(box):
                box.collapsedStateChanged.disconnect(changed)
        self._collapsibles = {}
        for button, clicked in self._toggles.values():
            if not sip.isdeleted(button):
                button.clicked.disconnect(clicked)
        self._toggles = {}
        for widget, size in self._page_lists.values():
            if not sip.isdeleted(widget):
                widget.setIconSize(size)
        self._page_lists = {}
        for view, size in self._trees.values():
            if not sip.isdeleted(view):
                view.setIconSize(size)
        self._trees = {}
        for toolbar, size in self._panel_bars.values():
            if not sip.isdeleted(toolbar):
                toolbar.setIconSize(size)
        self._panel_bars = {}
        for (field,) in self._searches.values():
            if not sip.isdeleted(field):
                field.setProperty("showSearchIcon", False)
        self._searches = {}
        for (tree,) in self._row_focus.values():
            if not sip.isdeleted(tree):
                tree.setAllColumnsShowFocus(True)
        self._row_focus = {}
        for dialog, own in self._rooms.values():
            if not sip.isdeleted(dialog):
                dialog.setMinimumSize(own)
        self._rooms = {}
        for (page,) in self._relaxed.values():
            if not sip.isdeleted(page):
                policy = page.sizePolicy()
                if policy.horizontalPolicy() == QSizePolicy.Policy.Expanding:
                    policy.setHorizontalPolicy(self._MINIMUM_EXPANDING)
                    page.setSizePolicy(policy)
        self._relaxed = {}
        for edit in self._pickers.values():
            # Back to QGIS's own black (its filter is removed above).
            if not sip.isdeleted(edit):
                palette = edit.palette()
                palette.setColor(QPalette.ColorRole.Text, QColor(Qt.GlobalColor.black))
                edit.setPalette(palette)
        self._pickers = {}
        for action, recheck in self._watched.items():
            if sip.isdeleted(action):
                continue
            action.changed.disconnect(recheck)
            builtin = self._builtin(action.icon())
            if builtin is not None:
                action.setIcon(builtin)
        self._watched = {}
        # A slot is restored by the icon it shows now, not by its position:
        # rows may have been added, removed or reordered since the swap, so
        # the icon saved for row 3 may belong to another row by now. Each
        # slot still showing one of our icons gets the built-in version of
        # that very icon (the saved original when it is the same one).
        for owner, kind, index, icon in reversed(self._swapped):
            if sip.isdeleted(owner) or not self._valid(owner, kind, index):
                continue
            current = self._get(owner, kind, index)
            name = self._ours.get(current.cacheKey())
            if name is None:
                continue
            original = icon if self._names.get(icon.cacheKey()) == name else self._builtin(current)
            if original is not None:
                self._set(owner, kind, index, original)
        self._swapped = []
        for root in self._scanned:
            if not sip.isdeleted(root):
                root.setProperty(self.PROPERTY, None)
        self._scanned = []
        self._compact_at = self.COMPACT_MIN


class _Relay(QObject):
    """Carries worker-thread results to the GUI thread (queued signal)."""
    pngs_ready = pyqtSignal(object)


class SettingsDialog(QDialog):
    """Plugins > QGIS Studio Themes > Settings: the interface (toolbars or
    the ribbon), the icon style, the ribbon's size and density, and where
    the names go, which name they show and in what size and weight: the
    toolbars' names, or in ribbon mode its groups' names (each interface
    keeps its own position and name; the font is shared). Only what
    applies to the interface chosen can be changed. Every change shows at
    once, so the dialog only has Close."""

    INTERFACES = (
        ("toolbars", "Toolbars"),
        ("ribbon", "Ribbon"),
    )
    ICON_STYLES = (
        ("mono", "Monochrome"),
        ("color", "Colourful"),
        ("classic", "QGIS classic"),
    )
    RIBBON_SIZES = (
        ("auto", "Follow QGIS icon size"),
        ("small", "Small"),
        ("medium", "Medium"),
        ("large", "Large"),
    )
    DENSITIES = (
        ("compact", "Compact"),
        ("standard", "Standard (default)"),
    )

    POSITIONS = (
        ("off", "Off"),
        ("top", "Above the buttons"),
        ("bottom", "Below the buttons, in the line"),
        ("left", "Left of the buttons"),
        ("left_vertical", "Left of the buttons, vertical"),
    )
    # The ribbon's groups have no line to put a name in.
    RIBBON_BOTTOM = "Below the buttons"
    NAMES = (
        ("auto", "Auto: full where it fits, short otherwise"),
        ("full", "Full"),
        ("short", "Short (up to four letters)"),
    )
    WEIGHTS = (
        ("bold", "Bold"),
        ("regular", "Regular"),
        ("light", "Light"),
    )

    def __init__(self, plugin, parent=None):
        super().__init__(parent)
        self._plugin = plugin
        self.setWindowTitle("QGIS Studio Themes Settings")
        self.setMinimumWidth(460)
        _position, _names, size, weight = plugin.label_style()
        _position, _names, _size, _weight, ribbon_size, density = plugin.ribbon_style()
        self._interface = self._combo(self.INTERFACES, plugin.interface())
        self._icon_style = self._combo(self.ICON_STYLES, plugin.icon_style())
        self._icon_style.setToolTip(
            "Monochrome: the theme's single-colour icons. Colourful: the same icons in their objects' "
            "own colours. QGIS classic: QGIS's own icons."
        )
        self._ribbon_size = self._combo(self.RIBBON_SIZES, ribbon_size)
        self._ribbon_size.setToolTip(
            "The ribbon's icons and rows: as QGIS's toolbar icon size (Options > General) would make "
            "them, or a size of their own."
        )
        self._density = self._combo(self.DENSITIES, density)
        self._density.setToolTip(
            "Compact keeps the icons' sizes and leaves less room around them, so the ribbon takes "
            "less of the window's height."
        )
        self._position = self._combo(self.POSITIONS, None)
        self._names = self._combo(self.NAMES, None)
        self._size = QComboBox()
        for value in TITLE_SIZES:
            self._size.addItem(f"{value} px" + (" (default)" if value == TITLE_SIZE else ""), value)
        self._size.setCurrentIndex(max(0, self._size.findData(size)))
        self._weight = self._combo(self.WEIGHTS, weight)
        self._form = form = QFormLayout()
        form.addRow("Interface", self._interface)
        form.addRow("Icons", self._icon_style)
        form.addRow("Ribbon size", self._ribbon_size)
        form.addRow("Ribbon density", self._density)
        form.addRow("Toolbar name position", self._position)
        form.addRow("Toolbar name", self._names)
        form.addRow("Font size", self._size)
        form.addRow("Font weight", self._weight)
        self._note = note = QLabel()
        note.setWordWrap(True)
        self._inactive = QLabel("Toolbar names and the ribbon show while a Studio theme is in use.")
        self._inactive.setWordWrap(True)
        buttons = QDialogButtonBox(QDialogButtonBox.StandardButton.Close)
        buttons.rejected.connect(self.close)
        layout = QVBoxLayout(self)
        layout.addLayout(form)
        layout.addWidget(note)
        layout.addWidget(self._inactive)
        layout.addStretch(1)
        layout.addWidget(buttons)
        self._load_names()
        self._fit_names()
        for combo in (self._position, self._names, self._size, self._weight, self._ribbon_size, self._density):
            combo.currentIndexChanged.connect(self._changed)
        self._interface.currentIndexChanged.connect(self._interface_changed)
        self._icon_style.currentIndexChanged.connect(self._icon_style_changed)

    @staticmethod
    def _combo(choices, current):
        combo = QComboBox()
        for value, text in choices:
            combo.addItem(text, value)
        if current is not None:
            combo.setCurrentIndex(max(0, combo.findData(current)))
        return combo

    def _ribbon(self):
        return self._interface.currentData() == "ribbon"

    def _load_names(self):
        """Show the name position and name of the interface chosen."""
        if self._ribbon():
            position, names = self._plugin.ribbon_style()[:2]
        else:
            position, names = self._plugin.label_style()[:2]
        for combo, value in ((self._position, position), (self._names, names)):
            blocked = combo.blockSignals(True)
            combo.setCurrentIndex(max(0, combo.findData(value)))
            combo.blockSignals(blocked)

    def showEvent(self, event):  # pylint: disable=invalid-name
        self._inactive.setVisible(not self._plugin.studio_shown())
        super().showEvent(event)

    def _icon_style_changed(self, _index=None):
        self._plugin.set_icon_style(self._icon_style.currentData())

    def _interface_changed(self, _index=None):
        self._plugin.set_interface(self._interface.currentData())
        self._load_names()
        self._changed()

    def _changed(self, _index=None):
        self._fit_names()
        position, names = self._position.currentData(), self._names.currentData()
        size, weight = self._size.currentData(), self._weight.currentData()
        if self._ribbon():
            self._plugin.set_label_font(size, weight)
            self._plugin.set_ribbon_style(
                position, names, self._ribbon_size.currentData(), self._density.currentData())
        else:
            self._plugin.set_label_style(position, names, size, weight)
        self._plugin.settings_changed()

    def _fit_names(self):
        """No name to choose without names; no full names reading upwards
        (they rarely fit a toolbar's or a ribbon group's height): Auto
        shows them where they do. The rows name toolbars or, in ribbon
        mode, the ribbon's groups; the ribbon's size and density apply to
        it alone."""
        position = self._position.currentData()
        ribbon = self._ribbon()
        noun = "Group" if ribbon else "Toolbar"
        for widget, text in ((self._position, f"{noun} name position"), (self._names, f"{noun} name")):
            label = self._form.labelForField(widget)
            if label is not None:
                label.setText(text)
        self._position.setItemText(
            self._position.findData("bottom"), self.RIBBON_BOTTOM if ribbon else dict(self.POSITIONS)["bottom"])
        self._ribbon_size.setEnabled(ribbon)
        self._density.setEnabled(ribbon)
        self._names.setEnabled(position != "off")
        for combo in (self._size, self._weight):
            combo.setEnabled(position != "off")
        if ribbon:
            self._note.setText(
                "The ribbon shows every toolbar button in tabs. Its groups' names can go above or below "
                "the buttons, left of them, or be turned off to save height. Double-click a tab to "
                "collapse the ribbon. Toolbars in layout designers keep the toolbar names' settings."
            )
        else:
            self._note.setText(
                "Applies to toolbars docked in rows. Toolbars docked at the window's sides keep a short "
                "name on their handle, and floating toolbars show their name in their title bar. "
                "Hover over a toolbar to see its full name."
            )
        vertical = position == "left_vertical"
        self._names.model().item(self._names.findData("full")).setEnabled(not vertical)
        if vertical and self._names.currentData() == "full":
            blocked = self._names.blockSignals(True)
            self._names.setCurrentIndex(self._names.findData("auto"))
            self._names.blockSignals(blocked)


class QgisStudioThemesPlugin:
    """Registers the Studio themes and keeps the parts a stylesheet cannot
    reach (palette, font, icons, message bar) in sync with the active one."""

    # Display name (registered as "Studio <name>") -> folder under themes/
    THEMES = {
        "Premium Dark": "premium",
        "Web Dark": "web",
        "Orange Dark": "dark",
        "Pro Light": "pro",
        "Orange Light": "light_orange",
        "QGIS Light": "qgis_light",
    }
    # Former display names -> current ones (kept so saved settings follow).
    RENAMED = {
        "Studio Pro": "Studio Pro Light",
        "Studio Premium": "Studio Premium Dark",
        "Studio Web": "Studio Web Dark",
        "Studio Dark": "Studio Orange Dark",
        "Studio Light Orange": "Studio Orange Light",
    }

    def __init__(self, iface):
        self.iface = iface
        self._connected = False
        self._active = None
        self._tokens = {}
        self._original_palette, self._original_font = self._original_look()
        themes_folder = Path(QgsApplication.userThemesFolder())
        # One event filter per watched object for the icons and the toolbar
        # names, which both watch the main window and every toolbar.
        self._hub = EventHub()
        self._icons = IconSwapper(
            themes_folder / ".studio-icon-digests.json", themes_folder / ".studio-masks", self._hub
        )
        # Message bar items styled, with the slots connected to each.
        self._message_bar_slots = {}
        self._main_window_sheet = None
        self._prepared = None
        self._fonts_loaded = False
        self._shared_stamp = None
        self._stamp_base = None
        # One lock per theme serialises its build (background builder vs.
        # a runtime switch) and its style.qss.
        self._locks = {name: threading.Lock() for name in self.THEMES}
        self._stop = threading.Event()
        self._threads = []
        self._jobs = queue.Queue()
        self._worker_lock = threading.Lock()
        self._worker_running = False
        self._rendering = set()
        self._relay = _Relay()
        self._relay.pngs_ready.connect(self._pngs_ready)
        # Screens plugged in or out, a changed display scaling or QGIS icon
        # size: settled for a moment, then the icons follow (see
        # _sizes_changed). Signal connections, undone on unload.
        self._size_timer = QTimer()
        self._size_timer.setSingleShot(True)
        self._size_timer.setInterval(500)
        self._size_timer.timeout.connect(self._refresh_icon_sizes)
        self._size_hooks = []
        self._labels = ToolbarLabels(self._hub)
        self._ribbon = StudioRibbon(iface, self._hub, self._icons)
        # The Layers panel's search field and List by Data Source.
        self._layers = LayersPanel(iface, self._hub, self._icons)
        # QGIS has finished starting (every toolbar, plugins' too, is in
        # place): the ribbon is only built then.
        self._ready = False
        self._settings_action = None
        self._settings_dialog = None
        self._compact = False
        self._extra_tokens = {}
        # Themes (re)built by this plugin load, i.e. new or updated.
        self._rebuilt = set()

    @classmethod
    def _original_look(cls):
        """The palette and font to restore when leaving the Studio themes.
        Read once per QGIS session and kept on the application object: a
        plugin reloaded or upgraded while a Studio theme is shown would
        otherwise take the theme's palette and font for QGIS's own and
        keep them after switching back to another theme."""
        app = QApplication.instance()
        palette, font = app.property(ORIGINAL_PALETTE), app.property(ORIGINAL_FONT)
        if isinstance(palette, QPalette) and isinstance(font, QFont):
            return QPalette(palette), QFont(font)
        palette, font = QPalette(QApplication.palette()), QFont(QApplication.font())
        studio = {f"Studio {name}" for name in cls.THEMES} | set(cls.RENAMED)
        if QgsApplication.themeName() in studio:
            # Already themed (by a release that did not keep them): the
            # style's own palette, and the system font unless the user
            # chose one in QGIS.
            palette = QApplication.style().standardPalette()
            if not QgsSettings().contains("app/fontFamily"):
                font.setFamily(QFontDatabase.systemFont(QFontDatabase.SystemFont.GeneralFont).family())
        app.setProperty(ORIGINAL_PALETTE, palette)
        app.setProperty(ORIGINAL_FONT, font)
        return QPalette(palette), QFont(font)

    @staticmethod
    def theme_target(name):
        return Path(QgsApplication.userThemesFolder()) / f"Studio {name}"

    def initGui(self):
        try:
            self._init_gui()
        except Exception:
            # QGIS drops a plugin whose initGui fails (e.g. a read-only or
            # locked profile folder) without calling unload(): undo the
            # hooks, palette and font already installed, then report it.
            try:
                self.unload()
            except Exception:  # pylint: disable=broad-except
                pass
            raise

    def _init_gui(self):
        # QGIS applies the configured theme as soon as it is registered.
        # Install palette and font first so that single stylesheet pass
        # already sees them (no second, full repolish at startup).
        settings = QgsSettings()
        configured = settings.value("UI/UITheme", "", type=str)
        # The theme QGIS already shows: a Studio theme when the plugin is
        # installed or upgraded in a running QGIS (Plugin Manager), and its
        # icons, cached by QGIS, come from that theme's current files.
        running = QgsApplication.themeName()
        renamed_running = None
        for old_name, new_name in self.RENAMED.items():
            old_target = Path(QgsApplication.userThemesFolder()) / old_name
            if running == old_name:
                # Removed at the next start instead: deleting the files now
                # would blank the icons QGIS cached from them.
                renamed_running = new_name
            elif (old_target / STAMP).exists():
                shutil.rmtree(old_target, ignore_errors=True)
            if configured == old_name:
                configured = new_name
                settings.setValue("UI/UITheme", configured)
        if configured in self._studio_themes():
            self._prepare(configured)
        QgsApplication.instance().themeChanged.connect(self._sync)
        self.iface.messageBar().widgetAdded.connect(self._style_message_bar)
        self.iface.layoutDesignerOpened.connect(self._label_designer)
        self.iface.initializationCompleted.connect(self._initialized)
        # Enabled in a running QGIS: no initializationCompleted to come.
        self._ready = self.iface.mainWindow().isVisible()
        self._connected = True
        self._settings_action = QAction(
            QgsApplication.getThemeIcon("mActionOptions.svg"), "Settings…", self.iface.mainWindow()
        )
        self._settings_action.triggered.connect(self._show_settings)
        self.iface.addPluginToMenu(MENU_NAME, self._settings_action)
        self._hook_sizes()
        self._compact = self._compact_sizes()
        # The main menu is one point larger than the UI font, so it reads as
        # the top level. The size goes into the theme stylesheet (a widget
        # stylesheet on the bar would give every menu, all children of the
        # bar, a slower style chain of its own) and into the build stamp, so
        # a changed QGIS font size rebuilds the themes.
        # From QGIS's font-size option (or the font QGIS started with), not
        # from the menu bar, which already carries this theme's larger size
        # when the plugin is reloaded while a Studio theme is active.
        base_size = QgsSettings().value(
            "qgis/stylesheet/fontPointSize", self._original_font.pointSizeF(), type=float
        )
        # Compact sizes: the menu and panel titles stay closer to the UI
        # font, panels keep QGIS's own icon size and icons are enlarged less.
        compact = self._compact
        menu_size = base_size + (COMPACT_MENU_BAR_EXTRA_PT if compact else MENU_BAR_EXTRA_PT)
        self._extra_tokens = {
            "@menu_font_size": f"{menu_size:g}pt",
            "@panel_title_font_size": f"{base_size + (0 if compact else 1):g}pt",
            # Section (group box) titles: the panel titles' size.
            "@section_font_size": f"{base_size + (0 if compact else 1):g}pt",
            "@ui_font_size": f"{base_size:g}pt",
            "@menu_item_padding_x": "11px" if compact else "14px",
            # One height for fields, combo boxes and push buttons (28 px,
            # compact 26 px), so a row of them lines up; panel search
            # fields are pills of that height.
            "@control_padding_y": "3px" if compact else "4px",
            # With the 2 px focus ring: 1 px less, so the text stays put.
            "@control_padding_y_focus": "2px" if compact else "3px",
            "@search_radius": "13px" if compact else "14px",
            "@panel_icon_rules": "" if compact else PANEL_ICON_RULES,
            # Toolbar name strips and handles, a rule per size (see
            # studio_toolbars).
            "@toolbar_name_rules": name_rules(),
        }
        self._stamp_base = (
            BUILD_FORMAT + build_stamp(shared_sources()) + f"|menu{menu_size:g}"
            + ("|compact" if compact else "")
        )
        self._shared_stamp = self._stamp_base + f"|icons-{self.icon_style()}"
        # Only the configured theme is built now; the others only need a
        # placeholder style.qss to be registered and are built in the
        # background (or on demand, if selected first).
        registered = []
        pending = []
        for name in self.THEMES:
            if f"Studio {name}" == configured:
                if self._build(name, active=True):
                    registered.append(name)
                continue
            style = self.theme_target(name) / "style.qss"
            if not style.exists():
                style.parent.mkdir(parents=True, exist_ok=True)
                style.write_bytes(STUB_STYLE)
            registered.append(name)
            pending.append(name)
        # Before registering: QGIS loads the configured theme's style.qss
        # as soon as that theme is registered.
        self._select_style(configured)
        for name in registered:
            QgsApplication.applicationThemeRegistry().addTheme(
                f"Studio {name}", self.theme_target(name).as_posix()
            )
        if renamed_running is not None and renamed_running == configured:
            # Upgraded while QGIS shows a theme under its former name: move
            # QGIS to the new name now, not only at the next start.
            QgsApplication.setUITheme(configured)
        # When the configured theme is applied later, themeChanged syncs;
        # syncing now would undo the preparation above.
        studio = self._studio_themes()
        if QgsApplication.themeName() in studio:
            self._sync()
        if (running in studio or running in self.RENAMED) and configured in studio and (
            studio[configured][0] in self._rebuilt
        ):
            # QGIS cached some icons from the previous version's files
            # (e.g. Browser provider icons) and offers no way to drop them.
            self.iface.messageBar().pushMessage(
                "Studio Themes", "Updated. Restart QGIS once so every icon shows the new version.",
                Qgis.MessageLevel.Info, 30,
            )
        QTimer.singleShot(2000, lambda: self._start(self._build_pending, pending))

    def _build(self, name, active=False):
        """Build one theme (no-op when up to date); False if it failed."""
        scale = studio_icons.COMPACT_SCALE if self._compact else studio_icons.SCALE
        with self._locks[name]:
            try:
                if build_theme(
                    self.THEMES[name], self.theme_target(name), self._shared_stamp, active,
                    self._extra_tokens, scale, self.icon_style(),
                ):
                    self._rebuilt.add(name)
            except Exception as error:  # pylint: disable=broad-except
                QgsMessageLog.logMessage(
                    f"Could not build Studio {name}: {error}", LOG_TAG, Qgis.MessageLevel.Critical
                )
                return False
        return True

    def _build_pending(self, names):
        for name in names:
            if self._stop.is_set():
                return
            self._build(name)

    def _start(self, target, *args):
        """Queue `target` for the single background worker: theme builds
        and PNG pre-rendering run one after another, never in parallel, so
        they compete less with the GUI thread for Python's lock."""
        if self._stop.is_set():
            return
        with self._worker_lock:
            self._jobs.put((target, args))
            if not self._worker_running:
                self._worker_running = True
                thread = threading.Thread(target=self._work, daemon=True)
                self._threads = [thread]
                thread.start()

    def _work(self):
        while not self._stop.is_set():
            try:
                target, args = self._jobs.get(timeout=0.5)
            except queue.Empty:
                # Exit only if nothing was queued meanwhile; _start checks
                # the same flag under the same lock, so no job is dropped.
                with self._worker_lock:
                    if self._jobs.empty():
                        self._worker_running = False
                        return
                continue
            try:
                target(*args)
            except Exception as error:  # pylint: disable=broad-except
                # One failed job must not end the worker: it would stay
                # flagged as running and every later job would wait forever.
                QgsMessageLog.logMessage(
                    f"Background task failed: {error!r}", LOG_TAG, Qgis.MessageLevel.Warning
                )
        with self._worker_lock:
            self._worker_running = False

    def unload(self):
        self._stop.set()
        # A theme build does not stop half way (its files must stay
        # consistent); the worker is a daemon thread, so do not freeze
        # QGIS waiting for it.
        for thread in self._threads:
            thread.join(timeout=2)
        self._threads = []
        if self._connected:
            QgsApplication.instance().themeChanged.disconnect(self._sync)
            self.iface.messageBar().widgetAdded.disconnect(self._style_message_bar)
            self.iface.layoutDesignerOpened.disconnect(self._label_designer)
            self.iface.initializationCompleted.disconnect(self._initialized)
            self._connected = False
        if self._settings_action is not None:
            self.iface.removePluginMenu(MENU_NAME, self._settings_action)
            self._settings_action.deleteLater()
            self._settings_action = None
        if self._settings_dialog is not None:
            if not sip.isdeleted(self._settings_dialog):
                self._settings_dialog.close()
                self._settings_dialog.deleteLater()
            self._settings_dialog = None
        self._size_timer.stop()
        for signal, slot in self._size_hooks:
            try:
                signal.disconnect(slot)
            except (TypeError, RuntimeError):
                pass  # the screen is gone
        self._size_hooks = []
        # Message bar items keep their slots otherwise: a reloaded plugin's
        # old instance would live on through them.
        for item, (restyle, forget) in self._message_bar_slots.items():
            if not sip.isdeleted(item):
                item.styleChanged.disconnect(restyle)
                item.destroyed.disconnect(forget)
        self._message_bar_slots = {}
        studio_shown = self._active is not None
        self._deactivate()
        if studio_shown:
            # Disabled or uninstalled while a Studio theme is shown: its
            # stylesheet would stay on top of QGIS's own palette until a
            # restart. (An upgraded or reloaded plugin applies it again.)
            QApplication.instance().setStyleSheet("")
        for name in self.THEMES:
            QgsApplication.applicationThemeRegistry().removeTheme(f"Studio {name}")

    # ---- Theme state ------------------------------------------------------

    def _select_style(self, active):
        """Give QGIS the real stylesheet only for `active` (the theme it
        will load at startup) and the placeholder for the others. Sizes
        tell them apart (style.qss is only ever one of the two), so this
        costs a few stat() calls instead of reading every stylesheet."""
        for name in self.THEMES:
            is_active = f"Studio {name}" == active
            lock = self._locks[name]
            # A theme being built in the background gets the placeholder
            # from its build; the active one must not be skipped.
            if not lock.acquire(blocking=is_active):
                continue
            try:
                target = self.theme_target(name)
                full = target / FULL_STYLE
                current = target / "style.qss"
                if not full.exists():
                    continue
                size = current.stat().st_size if current.exists() else -1
                if is_active:
                    if size != full.stat().st_size:
                        shutil.copyfile(full, current)
                elif size != len(STUB_STYLE):
                    current.write_bytes(STUB_STYLE)
            finally:
                lock.release()

    def _studio_themes(self):
        return {f"Studio {name}": (name, folder) for name, folder in self.THEMES.items()}

    def _prepare(self, theme):
        """Everything that must be in place before the stylesheet is
        polished: Qt bakes the current palette and font into each styled
        widget during polish, so later changes would not reach them."""
        name, folder = self._studio_themes()[theme]
        self._tokens = load_tokens(folder)
        dark = is_dark(self._tokens["@bg_window"])
        self._set_color_scheme("Dark" if dark else "Light")
        QApplication.setPalette(make_palette(self._tokens))
        if not QgsSettings().contains("app/fontFamily"):
            if not self._fonts_loaded:
                for font_file in sorted(FONTS_DIR.glob("*.ttf")):
                    QFontDatabase.addApplicationFont(str(font_file))
                self._fonts_loaded = True
            font = QFont(self._original_font)
            font.setFamily(self._tokens["@font_family"].strip("\"'"))
            set_tabular_digits(font)
            QApplication.setFont(font)
        window = self.iface.mainWindow()
        sheet = window.styleSheet()
        cleaned = DEFAULT_THEME_RULES.sub("", sheet)
        if cleaned != sheet:
            if self._main_window_sheet is None:
                self._main_window_sheet = sheet
            window.setStyleSheet(cleaned)
        self._prepared = theme

    def _sync(self):
        theme = QgsApplication.themeName()
        studio = self._studio_themes()
        if theme not in studio:
            self._deactivate()
            return
        if theme == self._active:
            return
        if not self._build(studio[theme][0]):
            self._deactivate()
            return
        app = QApplication.instance()
        full = self.theme_target(studio[theme][0]) / FULL_STYLE
        sheet = full.read_text(encoding="utf-8")
        if self._prepared != theme or app.styleSheet() != sheet:
            # Switched at runtime: QGIS has just applied the near-empty
            # placeholder, which already dropped the palette copies Qt kept
            # on widgets styled under the previous theme. The palette goes
            # in before the real stylesheet, so every widget is polished
            # once, with the right colours. (Another stylesheet: the plugin
            # was upgraded or reloaded in a running QGIS, which still shows
            # the previous version's, or none after its unload.)
            if self._prepared != theme:
                self._prepare(theme)
            app.setStyleSheet(sheet)
            self._select_style(theme)
        self._active = theme
        set_popup_shadows(False)
        name = studio[theme][0]
        icons_dir = self.theme_target(name) / "icons"
        scale = studio_icons.COMPACT_SCALE if self._compact else studio_icons.SCALE
        colors = tuple(
            {role: qcolor(value) for role, value in state.items()} for state in icon_colors(self._tokens)
        )
        if self._icons.style != self.icon_style():
            self._icons.set_style(self.icon_style())
        self._icons.apply(theme, icons_dir, self.iface.mainWindow(), colors, scale, compact=self._compact)
        self._layers.attach()
        self._style_message_bar()
        QTimer.singleShot(0, self._recolor_status_message)
        self._apply_labels()
        # Panel toolbars get their larger icons from the icon swapper
        # (_panel_toolbar), again after QGIS's own startup sizing.
        self._prerender()

    # ---- Compact sizes ----------------------------------------------------

    def _compact_sizes(self):
        """Compact sizes on screens with large pixels (low density). In
        logical pixels per inch, a 14 inch 1920x1200 laptop has ~160 and a
        24 inch monitor at the same resolution ~95: the same UI is ~1.7x
        larger there. Chosen automatically; a screen that reports a wrong
        physical size can be overridden by setting COMPACT_SETTING to "on"
        or "off" (no menu item: the automatic choice suits nearly every
        screen)."""
        mode = QgsSettings().value(COMPACT_SETTING, "auto", type=str)
        if mode in ("on", "off"):
            return mode == "on"
        window = self.iface.mainWindow()
        screen = (window.screen() if window is not None else None) or QGuiApplication.primaryScreen()
        if screen is None:
            return False
        # Screens that report no (or a nonsense) physical size keep the default.
        return 50 <= screen.physicalDotsPerInch() < COMPACT_MAX_PPI

    # ---- Toolbar labels ---------------------------------------------------

    @staticmethod
    def label_style():
        """(position, name style, size, weight) of the toolbar names, as
        set in the settings dialog: names above the buttons, the full name
        where the buttons are wide enough, in bold TITLE_SIZE px, by
        default."""
        settings = QgsSettings()
        position = settings.value(POSITION_SETTING, "", type=str)
        if position not in POSITIONS:
            position = "top" if settings.value(LABELS_SETTING, True, type=bool) else "off"
        names = settings.value(NAMES_SETTING, "auto", type=str)
        size = settings.value(SIZE_SETTING, TITLE_SIZE, type=int)
        weight = settings.value(WEIGHT_SETTING, "bold", type=str)
        return (
            position, names if names in NAME_STYLES else "auto", size if size in TITLE_SIZES else TITLE_SIZE,
            weight if weight in WEIGHTS else "bold",
        )

    @staticmethod
    def set_label_style(position, names, size, weight):
        settings = QgsSettings()
        settings.setValue(POSITION_SETTING, position)
        settings.setValue(NAMES_SETTING, names)
        settings.setValue(SIZE_SETTING, size)
        settings.setValue(WEIGHT_SETTING, weight)

    def _labels_enabled(self):
        return self.label_style()[0] != "off"

    @staticmethod
    def ribbon_style():
        """(position, name style, size, weight, ribbon size, density) of the
        ribbon: its groups' names (below the buttons, full where they fit, by default;
        in the toolbar names' font) and the size and density set in the
        settings dialog (QGIS's icon size, standard density by default)."""
        settings = QgsSettings()
        _position, _names, size, weight = QgisStudioThemesPlugin.label_style()
        position = settings.value(RIBBON_POSITION_SETTING, CAPTION_POSITION, type=str)
        names = settings.value(RIBBON_NAMES_SETTING, CAPTION_NAMES, type=str)
        ribbon_size = settings.value(RIBBON_SIZE_SETTING, "auto", type=str)
        density = settings.value(RIBBON_DENSITY_SETTING, DEFAULT_DENSITY, type=str)
        return (
            position if position in POSITIONS else CAPTION_POSITION,
            names if names in NAME_STYLES else CAPTION_NAMES,
            size, weight,
            ribbon_size if ribbon_size in RIBBON_SIZES else "auto",
            density if density in DENSITIES else DEFAULT_DENSITY,
        )

    @staticmethod
    def set_ribbon_style(position, names, ribbon_size, density):
        settings = QgsSettings()
        settings.setValue(RIBBON_POSITION_SETTING, position)
        settings.setValue(RIBBON_NAMES_SETTING, names)
        settings.setValue(RIBBON_SIZE_SETTING, ribbon_size)
        settings.setValue(RIBBON_DENSITY_SETTING, density)

    @staticmethod
    def set_label_font(size, weight):
        """The names' font, shared by toolbar and ribbon group names."""
        settings = QgsSettings()
        settings.setValue(SIZE_SETTING, size)
        settings.setValue(WEIGHT_SETTING, weight)

    @staticmethod
    def icon_style():
        """The icon style set in the settings dialog (ICON_STYLES)."""
        value = QgsSettings().value(ICON_STYLE_SETTING, "color", type=str)
        if value == "duotone":
            value = "color"  # its name in early 1.3 builds
        return value if value in ICON_STYLES else "color"

    def set_icon_style(self, style):
        """Show `style`'s icons at once: the active theme is rebuilt in it
        (the others when next shown), its icons swapped again from QGIS's
        own and the ribbon's pages rebuilt."""
        previous = self.icon_style()
        if style not in ICON_STYLES or style == previous:
            return
        QgsSettings().setValue(ICON_STYLE_SETTING, style)
        if self._stamp_base is None:
            return
        self._shared_stamp = self._stamp_base + f"|icons-{style}"
        theme = self._active
        if theme is None:
            return
        name = self._studio_themes()[theme][0]
        if not self._build(name):
            # Keep the style shown (the log has the error).
            QgsSettings().setValue(ICON_STYLE_SETTING, previous)
            self._shared_stamp = self._stamp_base + f"|icons-{previous}"
            self.iface.messageBar().pushMessage(
                "Studio Themes", "Could not change the icon style; see the QGIS Studio Themes log.",
                Qgis.MessageLevel.Warning, 10,
            )
            return
        # QGIS caches the icons it loaded from the theme folder: cleared by
        # applying the theme again, the plugin following in _sync. Those
        # it keeps by path (until it restarts) read the new files, once Qt
        # forgets the pixmaps it drew from the old ones.
        QPixmapCache.clear()
        self._icons.restore()
        self._active = None
        QgsApplication.setUITheme(theme)
        if self._active is None:
            self._sync()
        # After the icons are in place: the page shown is built at once.
        self._ribbon.refresh_icons()

    @staticmethod
    def interface():
        """The interface set in the settings dialog (INTERFACES)."""
        value = QgsSettings().value(INTERFACE_SETTING, "ribbon", type=str)
        return value if value in INTERFACES else "ribbon"

    @staticmethod
    def set_interface(interface):
        QgsSettings().setValue(INTERFACE_SETTING, interface)

    def _initialized(self):
        self._ready = True
        self._apply_labels()

    def studio_shown(self):
        """Whether a Studio theme is shown (the toolbar names with it)."""
        return self._active is not None

    def _show_settings(self):
        if self._settings_dialog is None or sip.isdeleted(self._settings_dialog):
            self._settings_dialog = SettingsDialog(self, self.iface.mainWindow())
        self._settings_dialog.show()
        self._settings_dialog.raise_()
        self._settings_dialog.activateWindow()

    def settings_changed(self):
        """The settings dialog changed a setting: shown at once."""
        self._apply_labels()

    def _label_color(self):
        """The dimmed text colour: the small capitals stay readable and
        quieter than the icons they name."""
        r, g, b, a = parse_color(self._tokens["@text_dim"])
        return QColor(round(r), round(g), round(b), round(a * 255))

    def _label_rule(self):
        """The dividers between titled toolbars: the shared line colour (@line)."""
        r, g, b, a = parse_color(self._tokens["@line"])
        return QColor(round(r), round(g), round(b), round(a * 255))

    def _label_row_rule(self):
        """The lines under rows of toolbars: the colour of the line under
        the menu bar (the dividers' too)."""
        r, g, b, a = parse_color(self._tokens["@line"])
        return QColor(round(r), round(g), round(b), round(a * 255))

    def _apply_labels(self):
        """Attach (or update) the toolbar labels for the active theme, or
        show the ribbon (the main window's toolbars hidden, so not named;
        layout designers keep their names)."""
        if self._active is None:
            self._ribbon.deactivate()
            self._labels.detach()
            return
        style = self.label_style()
        ribbon = self.interface() == "ribbon" and self._ready
        if ribbon:
            # Names off before the toolbars are hidden: they restore the
            # toolbars' own sizes.
            self._labels.detach()
            self._ribbon.set_style(*self.ribbon_style())
            self._ribbon.activate()
        else:
            self._ribbon.deactivate(forget=self.interface() != "ribbon")
        if not self._labels_enabled():
            self._labels.detach()
            return
        self._labels.set_style(*style)
        color, rule, row_rule = self._label_color(), self._label_rule(), self._label_row_rule()
        background = self._label_background()
        self._labels.set_color(color, rule, row_rule, background)
        if not ribbon:
            self._labels.attach(self.iface.mainWindow(), color, rule, row_rule, background)
        for designer in self.iface.openLayoutDesigners():
            self._labels.attach(designer.window(), color, rule, row_rule, background)

    def _label_designer(self, designer):
        if self._active is not None and self._labels_enabled():
            self._labels.attach(
                designer.window(), self._label_color(), self._label_rule(), self._label_row_rule(),
                self._label_background(),
            )

    def _label_background(self):
        """The toolbars' background (QToolBar in style.qss), which the
        names are drawn on."""
        return qcolor(self._tokens["@bg_window"])

    def _prerender(self):
        """Draw the icon masks these screens need and the profile does not
        hold yet (first start, other screens, sizes or plugin versions) in a
        worker thread, off startup's critical path; icons
        shown meanwhile move to them once they are ready. Every theme
        shares them, so switching themes draws nothing."""
        if self.icon_style() == "classic":
            return  # QGIS's own icons: no masks needed
        folders, scale = self._icons.mask_folders, self._icons.scale
        sizes = missing_masks(folders, self._icons.needed_png_sizes(), scale)
        if not folders or not sizes or scale in self._rendering:
            return
        self._rendering.add(scale)

        def work():
            try:
                if prerender_masks(folders, sizes, scale, self._stop):
                    self._relay.pngs_ready.emit(scale)
            finally:
                # Also after an error, so the next request tries again.
                self._rendering.discard(scale)

        QTimer.singleShot(3000, lambda: self._start(work))

    def _pngs_ready(self, _scale):
        """A worker finished drawing masks: move icons over, and draw any
        sizes asked for meanwhile (a screen plugged in during the run)."""
        self._icons.use_pngs()
        if self._active is not None:
            self._prerender()

    # ---- Screens and icon sizes -------------------------------------------

    def _hook_sizes(self):
        """Follow screens plugged in or out, display scaling changes and
        QGIS's toolbar icon size: each needs PNGs of other sizes."""
        app = QGuiApplication.instance()
        hooks = [(app.screenAdded, self._screen_added), (app.screenRemoved, self._sizes_changed)]
        window = self.iface.mainWindow()
        if window is not None:
            hooks.append((window.iconSizeChanged, self._sizes_changed))
        for signal, slot in hooks:
            signal.connect(slot)
        self._size_hooks = hooks
        for screen in app.screens():
            self._hook_screen(screen)

    def _hook_screen(self, screen):
        signal = screen.logicalDotsPerInchChanged
        signal.connect(self._sizes_changed)
        self._size_hooks.append((signal, self._sizes_changed))

    def _screen_added(self, screen):
        self._hook_screen(screen)
        self._sizes_changed()

    def _sizes_changed(self, *_args):
        self._size_timer.start()

    def _refresh_icon_sizes(self):
        """Icons that no longer fit the screens go back to the SVGs, and the
        missing masks are drawn in the background (then swapped in)."""
        if self._active is None:
            return
        self._icons.refresh_sizes()
        self._layers.resize()
        self._prerender()

    def _deactivate(self):
        if self._active is None and self._prepared is None:
            return
        self._active = None
        self._prepared = None
        self._ribbon.deactivate()
        self._layers.detach()
        self._labels.detach()
        self._icons.restore()
        set_popup_shadows(True)
        QApplication.setPalette(self._original_palette)
        QApplication.setFont(self._original_font)
        self._set_color_scheme("Unknown")
        if self._main_window_sheet is not None:
            self.iface.mainWindow().setStyleSheet(self._main_window_sheet)
            self._main_window_sheet = None
        bar = self.iface.messageBar()
        item = bar.currentItem()
        if item is not None and hasattr(item, "getStyleSheet"):
            bar.setStyleSheet(item.getStyleSheet())
        QTimer.singleShot(0, self._recolor_status_message)

    def _recolor_status_message(self):
        """QGIS writes the palette's text colour into the status bar
        message's own stylesheet when the palette changes, but reads it
        before a theme switch has set the new palette: the message kept the
        previous theme's colour (light grey, invisible on a light theme
        after a dark one, and on QGIS's own theme after a Studio one)."""
        window = self.iface.mainWindow()
        bar = window.statusBar() if window is not None else None
        if bar is None:
            return
        color = QApplication.palette().color(QPalette.ColorRole.WindowText).name()
        for widget in bar.findChildren(QLineEdit):
            parent = widget.parentWidget()
            if parent is None or not parent.inherits("QgsStatusBar"):
                continue
            sheet = widget.styleSheet()
            recolored = STATUS_TEXT_COLOR.sub(f"color: {color}", sheet)
            if recolored != sheet:
                widget.setStyleSheet(recolored)

    # ---- Message bar ------------------------------------------------------

    def _style_message_bar(self, item=None):
        """QGIS styles the bar per message level with fixed light colours
        (widget-level, so the app stylesheet cannot override it). Replace
        them with tinted theme colours after QGIS applied its own."""
        if self._active is None:
            return
        bar = self.iface.messageBar()
        # widgetAdded passes the item typed as a plain QWidget; the bar's
        # current item is the same object with its full API.
        item = bar.currentItem()
        if item is None:
            return
        if item not in self._message_bar_slots:
            restyle = lambda _sheet, item=item: self._style_message_bar(item)  # noqa: E731
            forget = lambda _obj=None, item=item: self._message_bar_slots.pop(item, None)  # noqa: E731
            self._message_bar_slots[item] = (restyle, forget)
            item.styleChanged.connect(restyle)
            item.destroyed.connect(forget)
        level = {
            Qgis.MessageLevel.Info: "info",
            Qgis.MessageLevel.Success: "success",
            Qgis.MessageLevel.Warning: "warning",
            Qgis.MessageLevel.Critical: "danger",
        }.get(item.level(), "info")
        t = self._tokens
        # A card on the raised surface, set in from the canvas edges, with a
        # stripe in the message level's colour; the count of further
        # messages is a quiet pill.
        bar.setStyleSheet(
            f"QgsMessageBar {{ background-color: {t['@bg_menu']};"
            f" border: 1px solid {t['@menu_edge']}; border-left: 3px solid {t[f'@{level}']};"
            f" border-radius: {t['@radius_lg']}; margin: 6px 8px 2px 8px; }}"
            f" QLabel, QTextEdit {{ color: {t['@text']}; background: transparent; border: none; }}"
            f" QLabel#mItemCount {{ color: {t['@text_dim']}; background-color: {t['@control_bg']};"
            " border-radius: 8px; padding: 1px 7px; }"
        )
        # The countdown of timed messages draws QGIS's own dark pause (and
        # play) image and a black edge through its own stylesheet: the
        # theme's images (QGIS swaps them by renaming the image in it) and
        # edge colour instead.
        countdown = bar.findChild(QProgressBar, "mCountdown")
        icons_dir = self._icons.icons_dir
        if countdown is not None and icons_dir is not None:
            sheet = countdown.styleSheet()
            themed = sheet.replace(":/images/themes/default/mIconTimer", f"{icons_dir.as_posix()}/mIconTimer")
            themed = themed.replace("rgba(0, 0, 0, 75%)", t["@menu_edge"])
            if themed != sheet:
                countdown.setStyleSheet(themed)
        # QGIS gives the Show more button black text on the button itself,
        # which the bar's stylesheet cannot override: the link colour.
        for button in item.findChildren(QToolButton):
            sheet = button.styleSheet()
            if "color: black" in sheet:
                button.setStyleSheet(sheet.replace("color: black", f"color: {t['@accent']}"))

    @staticmethod
    def _set_color_scheme(name):
        """Dark, Light or Unknown (follow the desktop). Qt.ColorScheme
        exists from Qt 6.5 and setColorScheme from 6.8; older Qt builds
        keep the desktop's scheme."""
        hints = QGuiApplication.styleHints()
        scheme = getattr(getattr(Qt, "ColorScheme", None), name, None)
        if scheme is not None and hasattr(hints, "setColorScheme"):
            hints.setColorScheme(scheme)
